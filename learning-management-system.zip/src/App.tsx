import React, { useState, useEffect } from 'react';
import { User, Course, PaymentTransaction, DashboardStats, ZoomSession, VideoRecording, UserRole } from './types';
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { CourseCatalog } from './components/CourseCatalog';
import { CourseDetailModal } from './components/CourseDetailModal';
import { PurchaseModal } from './components/PurchaseModal';
import { MyLearning } from './components/MyLearning';
import { ZoomLauncherModal } from './components/ZoomLauncherModal';
import { VideoPlayerModal } from './components/VideoPlayerModal';
import { LiveSchedule } from './components/LiveSchedule';
import { UserProfile } from './components/UserProfile';

// Admin Components
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminPaymentApprovals } from './components/admin/AdminPaymentApprovals';
import { AdminCourseManager } from './components/admin/AdminCourseManager';
import { AdminZoomRecorder } from './components/admin/AdminZoomRecorder';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [payments, setPayments] = useState<PaymentTransaction[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [allUsers, setAllUsers] = useState<User[]>([]);

  // Active Tab
  const [activeTab, setActiveTab] = useState<string>('explore');

  // Modals
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authIsRegister, setAuthIsRegister] = useState(false);

  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [purchasingCourse, setPurchasingCourse] = useState<Course | null>(null);
  const [launchingZoom, setLaunchingZoom] = useState<ZoomSession | null>(null);
  const [playingRecording, setPlayingRecording] = useState<VideoRecording | null>(null);

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Initial Data Fetch
  const fetchData = async () => {
    try {
      const [cRes, pRes, sRes, uRes] = await Promise.all([
        fetch('/api/courses'),
        fetch('/api/payments'),
        fetch('/api/stats'),
        fetch('/api/users'),
      ]);

      if (cRes.ok) {
        const cData = await cRes.json();
        setCourses(cData.courses || []);
      }
      if (pRes.ok) {
        const pData = await pRes.json();
        setPayments(pData.payments || []);
      }
      if (sRes.ok) {
        const sData = await sRes.json();
        setStats(sData);
      }
      if (uRes.ok) {
        const uData = await uRes.json();
        setAllUsers(uData.users || []);
      }
    } catch (err) {
      console.error('Error loading LMS data:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAccountSwitch = async (role: UserRole) => {
    const email = role === 'admin' ? 'admin@lms.edu' : 'student@lms.edu';
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, role }),
      });
      const data = await res.json();
      if (res.ok && data.user) {
        setUser(data.user);
        if (role === 'admin') {
          setActiveTab('admin-dashboard');
          showToast('Signed in to Admin Portal (admin@lms.edu)');
        } else {
          setActiveTab('explore');
          showToast('Signed in to Student Account (student@lms.edu)');
        }
      }
    } catch (err) {
      console.error('Account switch error:', err);
    }
  };

  const handleOpenAuth = (_role: UserRole = 'student', isRegister: boolean = false) => {
    setAuthIsRegister(isRegister);
    setIsAuthOpen(true);
  };

  const handleLogout = () => {
    setUser(null);
    setActiveTab('explore');
    showToast('Logged out of LMS Portal');
  };

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
    fetchData();
    if (loggedInUser.role === 'admin') {
      setActiveTab('admin-dashboard');
      showToast(`Welcome Admin, ${loggedInUser.name}`);
    } else {
      setActiveTab('explore');
      showToast(`Welcome Student, ${loggedInUser.name}`);
    }
  };

  // Purchase complete callback
  const handlePurchaseSuccess = (newPayment: PaymentTransaction, updatedUser: User) => {
    setUser(updatedUser);
    fetchData();

    if (newPayment.status === 'approved') {
      showToast(`🎉 Payment Authorized! Course "${newPayment.courseTitle}" is unlocked.`);
    } else {
      showToast(`📋 Bank Receipt Submitted! Queued for Admin Payment Approval.`);
    }
  };

  // Admin Actions
  const handleApprovePayment = async (paymentId: string) => {
    try {
      const res = await fetch(`/api/payments/${paymentId}/approve`, { method: 'PUT' });
      const data = await res.json();
      if (res.ok) {
        showToast('✅ Payment approved! Access granted to student.');
        fetchData();
        if (user && data.user && user.id === data.user.id) {
          setUser(data.user);
        }
      }
    } catch (err) {
      showToast('Failed to approve payment');
    }
  };

  const handleRejectPayment = async (paymentId: string, reason: string) => {
    try {
      const res = await fetch(`/api/payments/${paymentId}/reject`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      });
      if (res.ok) {
        showToast('Payment transaction rejected.');
        fetchData();
      }
    } catch (err) {
      showToast('Failed to reject payment');
    }
  };

  const handleCreateCourse = async (courseData: Partial<Course>) => {
    try {
      const res = await fetch('/api/courses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(courseData),
      });
      if (res.ok) {
        showToast('New Course Created!');
        fetchData();
      }
    } catch (err) {
      showToast('Error creating course');
    }
  };

  const handleUpdateCourse = async (courseId: string, updatedData: Partial<Course>) => {
    try {
      const res = await fetch(`/api/courses/${courseId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedData),
      });
      if (res.ok) {
        showToast('Course details updated!');
        fetchData();
      }
    } catch (err) {
      showToast('Error updating course');
    }
  };

  const handleDeleteCourse = async (courseId: string) => {
    try {
      const res = await fetch(`/api/courses/${courseId}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Course deleted.');
        fetchData();
      }
    } catch (err) {
      showToast('Error deleting course');
    }
  };

  const handleAddZoomSession = async (courseId: string, sessionData: Partial<ZoomSession>) => {
    try {
      const res = await fetch(`/api/courses/${courseId}/zoom-sessions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sessionData),
      });
      if (res.ok) {
        showToast('Zoom Live Class scheduled!');
        fetchData();
      }
    } catch (err) {
      showToast('Error adding Zoom session');
    }
  };

  const handleUpdateZoomSession = async (courseId: string, sessionId: string, sessionData: Partial<ZoomSession>) => {
    try {
      const res = await fetch(`/api/courses/${courseId}/zoom-sessions/${sessionId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sessionData),
      });
      if (res.ok) {
        showToast('Zoom Live Class updated permanently!');
        fetchData();
      }
    } catch (err) {
      showToast('Error updating Zoom session');
    }
  };

  const handleDeleteZoomSession = async (courseId: string, sessionId: string) => {
    try {
      const res = await fetch(`/api/courses/${courseId}/zoom-sessions/${sessionId}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Zoom session removed.');
        fetchData();
      }
    } catch (err) {
      showToast('Error deleting Zoom session');
    }
  };

  const handleAddRecording = async (courseId: string, recData: Partial<VideoRecording>) => {
    try {
      const res = await fetch(`/api/courses/${courseId}/recordings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(recData),
      });
      if (res.ok) {
        showToast('Video recording attached!');
        fetchData();
      }
    } catch (err) {
      showToast('Error adding recording');
    }
  };

  const handleUpdateRecording = async (courseId: string, recId: string, recData: Partial<VideoRecording>) => {
    try {
      const res = await fetch(`/api/courses/${courseId}/recordings/${recId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(recData),
      });
      if (res.ok) {
        showToast('Video recording details updated!');
        fetchData();
      }
    } catch (err) {
      showToast('Error updating recording');
    }
  };

  const handleDeleteRecording = async (courseId: string, recId: string) => {
    try {
      const res = await fetch(`/api/courses/${courseId}/recordings/${recId}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Video recording deleted.');
        fetchData();
      }
    } catch (err) {
      showToast('Error deleting recording');
    }
  };

  const pendingCount = payments.filter(p => p.status === 'pending').length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-indigo-500 selection:text-white flex flex-col">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-indigo-600 text-white px-5 py-3 rounded-2xl shadow-xl font-bold text-xs animate-bounce flex items-center space-x-2 border border-indigo-500">
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Navigation Bar */}
      <Navbar
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuth={handleOpenAuth}
        onLogout={handleLogout}
        pendingPaymentCount={pendingCount}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-24 md:pb-8">
        
        {/* Student Views */}
        {activeTab === 'explore' && (
          <CourseCatalog
            courses={courses}
            user={user}
            payments={payments}
            onSelectCourse={(c) => setSelectedCourse(c)}
            onPurchaseCourse={(c) => setPurchasingCourse(c)}
            onOpenAuth={() => handleOpenAuth('student', false)}
          />
        )}

        {activeTab === 'my-learning' && (
          <MyLearning
            user={user}
            courses={courses}
            onSelectCourse={(c) => setSelectedCourse(c)}
            onLaunchZoom={(s) => setLaunchingZoom(s)}
            onPlayRecording={(r) => setPlayingRecording(r)}
            onExploreCourses={() => setActiveTab('explore')}
          />
        )}

        {activeTab === 'live-schedule' && (
          <LiveSchedule
            courses={courses}
            user={user}
            onLaunchZoom={(s) => setLaunchingZoom(s)}
            onOpenAuth={() => handleOpenAuth('student', false)}
            onExploreCourses={() => setActiveTab('explore')}
          />
        )}

        {activeTab === 'profile' && user && (
          <UserProfile
            user={user}
            payments={payments}
            onUpdateProfile={(updated) => setUser(updated)}
            onExploreCourses={() => setActiveTab('explore')}
          />
        )}

        {/* Admin Views */}
        {activeTab === 'admin-dashboard' && user?.role === 'admin' && (
          <AdminDashboard
            stats={stats}
            payments={payments}
            courses={courses}
            users={allUsers}
            onNavigateTab={setActiveTab}
            onApprovePayment={handleApprovePayment}
            onUsersUpdated={fetchData}
          />
        )}

        {activeTab === 'admin-payments' && user?.role === 'admin' && (
          <AdminPaymentApprovals
            payments={payments}
            onApprove={handleApprovePayment}
            onReject={handleRejectPayment}
          />
        )}

        {activeTab === 'admin-courses' && user?.role === 'admin' && (
          <AdminCourseManager
            courses={courses}
            onCreateCourse={handleCreateCourse}
            onUpdateCourse={handleUpdateCourse}
            onDeleteCourse={handleDeleteCourse}
          />
        )}

        {activeTab === 'admin-zoom' && user?.role === 'admin' && (
          <AdminZoomRecorder
            courses={courses}
            onAddZoomSession={handleAddZoomSession}
            onUpdateZoomSession={handleUpdateZoomSession}
            onDeleteZoomSession={handleDeleteZoomSession}
            onAddRecording={handleAddRecording}
            onUpdateRecording={handleUpdateRecording}
            onDeleteRecording={handleDeleteRecording}
          />
        )}

      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 text-slate-500 text-xs py-8 mb-16 md:mb-0 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-slate-800">Academia LMS Platform</span>
            <span>• Live Zoom Classes & Recorded Modules</span>
          </div>
          <div className="flex items-center space-x-4">
            <button onClick={() => handleOpenAuth('student', false)} className="hover:text-slate-800 transition-colors">
              Log In
            </button>
            <span>•</span>
            <button onClick={() => handleOpenAuth('student', true)} className="hover:text-slate-800 transition-colors">
              Create Student Account
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
        initialIsRegister={authIsRegister}
      />

      <CourseDetailModal
        course={selectedCourse}
        user={user}
        payments={payments}
        onClose={() => setSelectedCourse(null)}
        onPurchase={(c) => setPurchasingCourse(c)}
        onLaunchZoom={(s) => setLaunchingZoom(s)}
        onPlayRecording={(r) => setPlayingRecording(r)}
      />

      <PurchaseModal
        course={purchasingCourse}
        user={user}
        onClose={() => setPurchasingCourse(null)}
        onSuccess={handlePurchaseSuccess}
      />

      <ZoomLauncherModal
        session={launchingZoom}
        onClose={() => setLaunchingZoom(null)}
      />

      <VideoPlayerModal
        recording={playingRecording}
        onClose={() => setPlayingRecording(null)}
      />

    </div>
  );
}

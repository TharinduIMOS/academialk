import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getAnalytics, isSupported } from 'firebase/analytics';

// User's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyDHpS609exgVbVInpDvMGhxTW92Y6XlaWY",
  authDomain: "jbxlms.firebaseapp.com",
  projectId: "jbxlms",
  storageBucket: "jbxlms.firebasestorage.app",
  messagingSenderId: "693304242718",
  appId: "1:693304242718:web:f782023e98d66f5e3f340f",
  measurementId: "G-X41LF83HGR"
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const db = getFirestore(app);
export const auth = getAuth(app);

// Initialize Analytics safely in browser environment
export const analyticsPromise = typeof window !== 'undefined' 
  ? isSupported().then(yes => yes ? getAnalytics(app) : null).catch(() => null)
  : null;

export default app;

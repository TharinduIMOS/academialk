import React, { useState } from 'react';
import { Course } from '../../types';
import { BookOpen, Plus, Edit2, Trash2, X, Save, Image, Star, DollarSign, Upload, User as UserIcon } from 'lucide-react';

interface AdminCourseManagerProps {
  courses: Course[];
  onCreateCourse: (courseData: Partial<Course>) => void;
  onUpdateCourse: (courseId: string, updatedData: Partial<Course>) => void;
  onDeleteCourse: (courseId: string) => void;
}

export const AdminCourseManager: React.FC<AdminCourseManagerProps> = ({
  courses,
  onCreateCourse,
  onUpdateCourse,
  onDeleteCourse,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Physics');
  const [batch, setBatch] = useState('2026 A/L');
  const [description, setDescription] = useState('');
  const [instructor, setInstructor] = useState('');
  const [instructorAvatar, setInstructorAvatar] = useState('');
  const [instructorTitle, setInstructorTitle] = useState('');
  const [price, setPrice] = useState('3000');
  const [originalPrice, setOriginalPrice] = useState('4000');
  const [image, setImage] = useState('');
  const [duration, setDuration] = useState('Monthly Subscription');
  const [level, setLevel] = useState<'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels'>('Advanced');
  const [scheduleText, setScheduleText] = useState('Tue & Thu @ 6:00 PM EST');
  const [tags, setTags] = useState('Theory, Revision, Paper Class');

  const openAddModal = () => {
    setEditingCourse(null);
    setTitle('');
    setCategory('Physics');
    setBatch('2026 A/L');
    setDescription('');
    setInstructor('Prof. K. Samarasinghe');
    setInstructorAvatar('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80');
    setInstructorTitle('Senior Physics Master & University Lecturer');
    setPrice('3000');
    setOriginalPrice('4000');
    setImage('https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=800&auto=format&fit=crop&q=80');
    setDuration('Monthly Subscription');
    setLevel('Advanced');
    setScheduleText('Tue & Thu @ 6:00 PM EST');
    setTags('Physics, 2026 A/L, Revision');
    setIsModalOpen(true);
  };

  const openEditModal = (course: Course) => {
    setEditingCourse(course);
    setTitle(course.title);
    setCategory(course.category);
    setBatch(course.batch || '2026 A/L');
    setDescription(course.description);
    setInstructor(course.instructor);
    setInstructorAvatar(course.instructorAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80');
    setInstructorTitle(course.instructorTitle || 'Senior Master & Educator');
    setPrice(String(course.price));
    setOriginalPrice(course.originalPrice ? String(course.originalPrice) : '');
    setImage(course.image);
    setDuration(course.duration);
    setLevel(course.level);
    setScheduleText(course.scheduleText);
    setTags(course.tags.join(', '));
    setIsModalOpen(true);
  };

  const handleBannerFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleInstructorAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setInstructorAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const coursePayload = {
      title,
      category,
      batch,
      description,
      instructor,
      instructorAvatar: instructorAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      instructorTitle: instructorTitle || 'Senior Subject Specialist',
      price: Number(price),
      originalPrice: originalPrice ? Number(originalPrice) : undefined,
      image: image || 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=800&auto=format&fit=crop&q=80',
      duration,
      level,
      scheduleText,
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
    };

    if (editingCourse) {
      onUpdateCourse(editingCourse.id, coursePayload);
    } else {
      onCreateCourse(coursePayload);
    }

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-8 rounded-3xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full w-fit">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Course Catalog Management</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Manage LMS Courses</h1>
          <p className="text-xs text-slate-400">Add new courses, update pricing, descriptions, and instructors.</p>
        </div>

        <button
          id="btn-admin-add-course"
          onClick={openAddModal}
          className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all flex items-center space-x-2 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Course</span>
        </button>
      </div>

      {/* Course List Table / Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => (
          <div
            key={course.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-lg flex flex-col justify-between"
          >
            <div>
              <div className="h-40 w-full relative bg-slate-950">
                <img src={course.image} alt={course.title} className="w-full h-full object-cover" />
                <div className="absolute top-3 left-3 flex items-center space-x-1.5">
                  <span className="px-2 py-0.5 rounded bg-slate-900/80 text-xs font-semibold text-indigo-300 backdrop-blur-sm">
                    {course.category}
                  </span>
                  {course.batch && (
                    <span className="px-2 py-0.5 rounded bg-indigo-600/90 text-xs font-bold text-white shadow-xs">
                      {course.batch}
                    </span>
                  )}
                </div>
              </div>

              <div className="p-5 space-y-2">
                <h3 className="font-bold text-sm text-white line-clamp-1">{course.title}</h3>
                <div className="text-xs text-slate-400">Instructor: {course.instructor}</div>
                <div className="text-xs text-slate-400">{course.scheduleText}</div>
                
                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                  <span className="font-black text-white text-base">Rs. {course.price.toLocaleString()}</span>
                  <span className="text-slate-400">{course.zoomSessions.length} Zoom Sessions</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
              <button
                id={`btn-edit-course-${course.id}`}
                onClick={() => openEditModal(course)}
                className="px-3 py-1.5 rounded-lg bg-indigo-600/20 text-indigo-300 hover:bg-indigo-600/30 text-xs font-semibold flex items-center space-x-1 transition-colors"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit Details</span>
              </button>

              <button
                id={`btn-delete-course-${course.id}`}
                onClick={() => {
                  if (confirm(`Delete course "${course.title}"?`)) {
                    onDeleteCourse(course.id);
                  }
                }}
                className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/20 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
          <div className="relative max-w-xl w-full bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl p-6 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="font-bold text-sm text-white">
                {editingCourse ? 'Edit Course Details' : 'Create New LMS Course'}
              </span>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Course Title</label>
                <input
                  id="input-course-title"
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Category / Subject</label>
                  <select
                    id="select-course-category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Physics">Physics</option>
                    <option value="Chemistry">Chemistry</option>
                    <option value="Combined Maths">Combined Maths</option>
                    <option value="Biology">Biology</option>
                    <option value="General">General</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Batch / Exam Year</label>
                  <select
                    id="select-course-batch"
                    value={batch}
                    onChange={(e) => setBatch(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-bold text-indigo-400"
                  >
                    <option value="2026 A/L">2026 A/L</option>
                    <option value="2027 A/L">2027 A/L</option>
                    <option value="2028 A/L">2028 A/L</option>
                    <option value="Revision">Revision</option>
                    <option value="Theory">Theory</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Level</label>
                  <select
                    id="select-course-level"
                    value={level}
                    onChange={(e) => setLevel(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                    <option value="All Levels">All Levels</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
                <textarea
                  id="input-course-desc"
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center space-x-1.5">
                  <UserIcon className="w-3.5 h-3.5" />
                  <span>Teacher / Instructor Profile Details</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Instructor Full Name</label>
                    <input
                      id="input-course-instructor"
                      type="text"
                      required
                      value={instructor}
                      onChange={(e) => setInstructor(e.target.value)}
                      placeholder="e.g. Prof. K. Samarasinghe"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Instructor Title / Designation</label>
                    <input
                      id="input-course-instructor-title"
                      type="text"
                      value={instructorTitle}
                      onChange={(e) => setInstructorTitle(e.target.value)}
                      placeholder="e.g. Senior Physics Master & Lecturer"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Teacher Profile Picture / Avatar</label>
                  <div className="flex items-center space-x-3 mb-2">
                    <img
                      src={instructorAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'}
                      alt="Instructor Avatar Preview"
                      className="w-12 h-12 rounded-xl object-cover border border-slate-700 shrink-0"
                    />
                    <label className="px-3 py-2 bg-indigo-900/60 hover:bg-indigo-800/80 text-indigo-200 border border-indigo-700/60 rounded-xl text-xs font-bold flex items-center space-x-1.5 cursor-pointer transition-all">
                      <Upload className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Upload Teacher Photo</span>
                      <input
                        id="input-file-instructor-avatar"
                        type="file"
                        accept="image/*"
                        onChange={handleInstructorAvatarFileUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                  <input
                    id="input-course-instructor-avatar"
                    type="text"
                    value={instructorAvatar}
                    placeholder="Or paste profile photo URL (https://...)"
                    onChange={(e) => setInstructorAvatar(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Tuition Fee (Rs. / LKR)</label>
                  <input
                    id="input-course-price"
                    type="number"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Original Price (Rs. - Optional Strikethrough)</label>
                  <input
                    id="input-course-orig-price"
                    type="number"
                    value={originalPrice}
                    onChange={(e) => setOriginalPrice(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Course Banner Image</label>
                <div className="flex items-center space-x-3 mb-2">
                  <img
                    src={image || 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=800&auto=format&fit=crop&q=80'}
                    alt="Course Banner Preview"
                    className="w-20 h-12 rounded-xl object-cover border border-slate-700 shrink-0"
                  />
                  <label className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center space-x-1.5 cursor-pointer transition-all">
                    <Upload className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Upload Banner Image</span>
                    <input
                      id="input-file-course-banner"
                      type="file"
                      accept="image/*"
                      onChange={handleBannerFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <input
                  id="input-course-image"
                  type="text"
                  value={image}
                  placeholder="Or paste banner image URL (https://...)"
                  onChange={(e) => setImage(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Schedule Text</label>
                <input
                  id="input-course-schedule"
                  type="text"
                  value={scheduleText}
                  onChange={(e) => setScheduleText(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  id="btn-save-course-form"
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-md shadow-indigo-600/30"
                >
                  {editingCourse ? 'Save Changes' : 'Create Course'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};

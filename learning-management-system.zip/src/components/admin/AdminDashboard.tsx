import React, { useState } from 'react';
import { DashboardStats, PaymentTransaction, Course, User } from '../../types';
import {
  Users,
  DollarSign,
  Clock,
  BookOpen,
  Video,
  ShieldCheck,
  ArrowRight,
  AlertCircle,
  UserPlus,
  Database,
  BarChart3,
  TrendingUp,
  Search,
  CheckCircle2,
  Server,
  Layers,
  Key,
  Calendar,
  Sparkles,
  Shield,
  Edit2,
  Trash2,
  X,
  Mail,
  Phone,
  UserCheck,
  Filter,
} from 'lucide-react';

interface AdminDashboardProps {
  stats: DashboardStats | null;
  payments: PaymentTransaction[];
  courses: Course[];
  users?: User[];
  onNavigateTab: (tab: string) => void;
  onApprovePayment: (paymentId: string) => void;
  onUsersUpdated?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  stats,
  payments,
  courses,
  users = [],
  onNavigateTab,
  onApprovePayment,
  onUsersUpdated,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'analytics' | 'admin-users' | 'database'>('analytics');
  const [searchQuery, setSearchQuery] = useState('');
  
  // User Account Management State
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | 'student' | 'admin'>('all');
  const [userSearchText, setUserSearchText] = useState('');

  // Edit User Modal State
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [editUserName, setEditUserName] = useState('');
  const [editUserEmail, setEditUserEmail] = useState('');
  const [editUserRole, setEditUserRole] = useState<'student' | 'admin'>('student');
  const [editUserPhone, setEditUserPhone] = useState('');
  const [editUserBio, setEditUserBio] = useState('');
  const [isSavingUser, setIsSavingUser] = useState(false);

  // Delete User Modal State
  const [deletingUser, setDeletingUser] = useState<User | null>(null);
  const [isDeletingUser, setIsDeletingUser] = useState(false);

  // Create Admin Form State
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminPhone, setNewAdminPhone] = useState('');
  const [newAdminBio, setNewAdminBio] = useState('Senior Administrator & Course Inspector');
  const [isSubmittingAdmin, setIsSubmittingAdmin] = useState(false);
  const [adminFeedback, setAdminFeedback] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);

  const handleOpenEditUser = (u: User) => {
    setEditingUser(u);
    setEditUserName(u.name);
    setEditUserEmail(u.email);
    setEditUserRole(u.role);
    setEditUserPhone(u.phone || '');
    setEditUserBio(u.bio || '');
  };

  const handleSaveEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setIsSavingUser(true);
    setAdminFeedback(null);
    try {
      const res = await fetch(`/api/admin/users/${editingUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editUserName,
          email: editUserEmail,
          role: editUserRole,
          phone: editUserPhone,
          bio: editUserBio,
        }),
      });

      if (res.ok) {
        setAdminFeedback({ type: 'success', msg: `Account for "${editUserName}" updated successfully!` });
        setEditingUser(null);
        if (onUsersUpdated) onUsersUpdated();
      } else {
        const data = await res.json();
        setAdminFeedback({ type: 'error', msg: data.error || 'Failed to update user' });
      }
    } catch (err: any) {
      setAdminFeedback({ type: 'error', msg: err.message || 'Error updating user' });
    } finally {
      setIsSavingUser(false);
    }
  };

  const handleConfirmDeleteUser = async () => {
    if (!deletingUser) return;
    setIsDeletingUser(true);
    setAdminFeedback(null);
    try {
      const res = await fetch(`/api/admin/users/${deletingUser.id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setAdminFeedback({ type: 'success', msg: `Account "${deletingUser.name}" deleted permanently!` });
        setDeletingUser(null);
        if (onUsersUpdated) onUsersUpdated();
      } else {
        const data = await res.json();
        setAdminFeedback({ type: 'error', msg: data.error || 'Failed to delete user' });
      }
    } catch (err: any) {
      setAdminFeedback({ type: 'error', msg: err.message || 'Error deleting user' });
    } finally {
      setIsDeletingUser(false);
    }
  };

  const filteredUsersList = users.filter((u) => {
    const matchesRole = userRoleFilter === 'all' ? true : u.role === userRoleFilter;
    const matchesSearch =
      u.name.toLowerCase().includes(userSearchText.toLowerCase()) ||
      u.email.toLowerCase().includes(userSearchText.toLowerCase()) ||
      (u.phone && u.phone.includes(userSearchText)) ||
      u.id.toLowerCase().includes(userSearchText.toLowerCase());
    return matchesRole && matchesSearch;
  });

  const pendingPayments = payments.filter((p) => p.status === 'pending');
  const approvedPayments = payments.filter((p) => p.status === 'approved');

  // Total Platform Approved Revenue
  const totalApprovedRevenue = approvedPayments.reduce((sum, p) => sum + (p.amount || 0), 0);

  // Compute Course-by-Course Analytics
  const courseAnalytics = courses.map((course) => {
    const courseApprovedPayments = approvedPayments.filter((p) => p.courseId === course.id);
    const coursePendingPayments = pendingPayments.filter((p) => p.courseId === course.id);

    const approvedRevenue = courseApprovedPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
    const pendingRevenue = coursePendingPayments.reduce((sum, p) => sum + (p.amount || 0), 0);

    // Registered distinct students for this course
    const distinctStudentIds = new Set(courseApprovedPayments.map((p) => p.userId));
    
    // Also check registered users in user array
    users.forEach((u) => {
      if (
        u.enrolledCourseIds?.includes(course.id) ||
        u.enrolledMonthKeys?.some((k) => k.startsWith(`${course.id}_`))
      ) {
        distinctStudentIds.add(u.id);
      }
    });

    // Breakdown per month
    const monthsBreakdown: Record<string, number> = {};
    (course.availableMonths || ['July 2026', 'August 2026', 'September 2026', 'October 2026', 'November 2026', 'December 2026']).forEach((m) => {
      const monthSales = courseApprovedPayments.filter((p) => p.month === m).length;
      monthsBreakdown[m] = monthSales;
    });

    const revenuePercent = totalApprovedRevenue > 0 ? (approvedRevenue / totalApprovedRevenue) * 100 : 0;

    return {
      course,
      approvedRevenue,
      pendingRevenue,
      approvedTransactionsCount: courseApprovedPayments.length,
      pendingTransactionsCount: coursePendingPayments.length,
      registeredStudentCount: distinctStudentIds.size,
      revenuePercent,
      monthsBreakdown,
    };
  });

  // Filtered Course Analytics
  const filteredAnalytics = courseAnalytics.filter((item) =>
    item.course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.course.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.course.instructor.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Admin users list
  const adminUsersList = users.filter((u) => u.role === 'admin');

  // Handle Admin User Creation
  const handleCreateAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdminName || !newAdminEmail) {
      setAdminFeedback({ type: 'error', msg: 'Name and email are required fields.' });
      return;
    }

    setIsSubmittingAdmin(true);
    setAdminFeedback(null);

    try {
      const res = await fetch('/api/admin/users/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newAdminName,
          email: newAdminEmail,
          role: 'admin',
          phone: newAdminPhone,
          bio: newAdminBio,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to create admin account');
      }

      setAdminFeedback({ type: 'success', msg: `Administrator account for "${newAdminName}" (${newAdminEmail}) created successfully!` });
      setNewAdminName('');
      setNewAdminEmail('');
      setNewAdminPhone('');

      if (onUsersUpdated) {
        onUsersUpdated();
      }
    } catch (err: any) {
      setAdminFeedback({ type: 'error', msg: err.message || 'An error occurred while creating admin account.' });
    } finally {
      setIsSubmittingAdmin(false);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-500/30">
            <ShieldCheck className="w-4 h-4 text-indigo-400" />
            <span>Administrator Control Center</span>
          </div>
          <span className="text-xs text-slate-400 font-mono">LMS Version 2.5 • Full Stack Mode</span>
        </div>

        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">Backend Analytics & Management</h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Categorize revenue course-by-course, track registered student counts, manage administrative accounts, and inspect database architecture.
          </p>
        </div>

        {/* Sub-tab Navigation Buttons */}
        <div className="pt-2 flex flex-wrap gap-2 border-t border-slate-800/80">
          <button
            id="admin-subtab-analytics"
            onClick={() => setActiveSubTab('analytics')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer ${
              activeSubTab === 'analytics'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Course Revenue & Student Counts</span>
          </button>

          <button
            id="admin-subtab-users"
            onClick={() => setActiveSubTab('admin-users')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer ${
              activeSubTab === 'admin-users'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4 text-indigo-300" />
            <span>Registered Accounts ({users.length})</span>
          </button>

          <button
            id="admin-subtab-database"
            onClick={() => setActiveSubTab('database')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 cursor-pointer ${
              activeSubTab === 'database'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <Database className="w-4 h-4 text-emerald-400" />
            <span>How Database Works</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        
        {/* Total Revenue */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Total Approved Revenue</span>
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">Rs. {(totalApprovedRevenue || stats?.totalRevenue || 0).toLocaleString()}</div>
          <div className="text-[11px] text-emerald-400 font-medium">Verified student payments</div>
        </div>

        {/* Pending Approvals */}
        <div
          onClick={() => onNavigateTab('admin-payments')}
          className="bg-slate-900 border border-slate-800 hover:border-amber-500/50 p-5 rounded-3xl space-y-3 shadow-lg cursor-pointer transition-colors group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Pending Approvals</span>
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black text-amber-300">{pendingPayments.length || stats?.pendingApprovals || 0}</div>
          <div className="text-[11px] text-amber-400/90 font-medium group-hover:underline flex items-center space-x-1">
            <span>Requires manual verification</span>
            <ArrowRight className="w-3 h-3" />
          </div>
        </div>

        {/* Registered Students */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Registered Students</span>
            <div className="p-2.5 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">{users.filter(u => u.role === 'student').length || stats?.totalStudents || 0}</div>
          <div className="text-[11px] text-indigo-400 font-medium">Active student accounts</div>
        </div>

        {/* Active Courses */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-3 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Active Courses</span>
            <div className="p-2.5 rounded-2xl bg-sky-500/20 text-sky-400 border border-sky-500/30">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">{courses.length || stats?.activeCourses || 0}</div>
          <div className="text-[11px] text-sky-400 font-medium">Across Physics, Maths & Chemistry</div>
        </div>

      </div>

      {/* Pending Payment Alert Box if any exist */}
      {pendingPayments.length > 0 && (
        <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-amber-950/60 border border-amber-500/40 p-5 rounded-3xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <AlertCircle className="w-5 h-5 text-amber-400" />
              <h3 className="font-bold text-sm text-white">
                Pending Student Payment Approvals ({pendingPayments.length})
              </h3>
            </div>
            <button
              id="btn-admin-view-all-pending"
              onClick={() => onNavigateTab('admin-payments')}
              className="text-xs font-bold text-amber-300 hover:text-white underline"
            >
              View Approvals Queue →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pendingPayments.slice(0, 2).map((pay) => (
              <div key={pay.id} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs">
                <div>
                  <div className="font-bold text-slate-100">{pay.userName} ({pay.month})</div>
                  <div className="text-slate-400 truncate text-[11px]">{pay.courseTitle}</div>
                </div>
                <div className="flex items-center space-x-2 shrink-0">
                  <span className="text-amber-400 font-mono font-bold">Rs. {pay.amount.toLocaleString()}</span>
                  <button
                    id={`btn-dash-approve-${pay.id}`}
                    onClick={() => onApprovePayment(pay.id)}
                    className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-colors cursor-pointer"
                  >
                    Approve
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-TAB 1: COURSE REVENUE & STUDENT REGISTRATION ANALYTICS */}
      {activeSubTab === 'analytics' && (
        <div className="space-y-6">
          
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-indigo-400" />
                  <h2 className="text-lg font-bold text-white">Course-by-Course Financial & Enrollment Breakdown</h2>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Categorized revenue earnings and registered student counts for each course.
                </p>
              </div>

              {/* Search filter */}
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Filter courses..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Course Breakdown Cards List */}
            <div className="space-y-4">
              {filteredAnalytics.map(({ course, approvedRevenue, pendingRevenue, approvedTransactionsCount, pendingTransactionsCount, registeredStudentCount, revenuePercent, monthsBreakdown }) => (
                <div
                  key={course.id}
                  className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-indigo-500/40 transition-all space-y-4 shadow-sm"
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    
                    {/* Course Identity */}
                    <div className="flex items-start space-x-4">
                      <img
                        src={course.image}
                        alt={course.title}
                        className="w-16 h-16 rounded-2xl object-cover border border-slate-800 shrink-0"
                      />
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 text-[10px] font-bold border border-indigo-500/30">
                            {course.category}
                          </span>
                          <span className="text-[11px] text-slate-400">Teacher: {course.instructor}</span>
                        </div>
                        <h3 className="font-bold text-base text-white">{course.title}</h3>
                        <div className="text-xs text-slate-400 flex items-center space-x-3">
                          <span>Tuition: <strong className="text-slate-200">Rs. {course.price.toLocaleString()}/month</strong></span>
                          <span>•</span>
                          <span>{course.scheduleText}</span>
                        </div>
                      </div>
                    </div>

                    {/* Stats Metrics for this Course */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 shrink-0">
                      
                      {/* Registered Students */}
                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-0.5">
                        <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider flex items-center justify-center space-x-1">
                          <Users className="w-3 h-3 text-indigo-400" />
                          <span>Students</span>
                        </div>
                        <div className="text-lg font-black text-indigo-300">{registeredStudentCount} enrolled</div>
                        <div className="text-[10px] text-slate-500">{approvedTransactionsCount} monthly payments</div>
                      </div>

                      {/* Approved Revenue */}
                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-0.5">
                        <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider flex items-center justify-center space-x-1">
                          <DollarSign className="w-3 h-3 text-emerald-400" />
                          <span>Approved Rev</span>
                        </div>
                        <div className="text-lg font-black text-emerald-400">Rs. {approvedRevenue.toLocaleString()}</div>
                        <div className="text-[10px] text-emerald-500">{revenuePercent.toFixed(1)}% of total</div>
                      </div>

                      {/* Pending Revenue */}
                      <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-0.5 col-span-2 sm:col-span-1">
                        <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider flex items-center justify-center space-x-1">
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>Pending Rev</span>
                        </div>
                        <div className="text-lg font-black text-amber-300">Rs. {pendingRevenue.toLocaleString()}</div>
                        <div className="text-[10px] text-amber-400/80">{pendingTransactionsCount} awaiting</div>
                      </div>

                    </div>
                  </div>

                  {/* Revenue Share Visual Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold">
                      <span>Platform Revenue Share</span>
                      <span>{revenuePercent.toFixed(1)}%</span>
                    </div>
                    <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                      <div
                        className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                        style={{ width: `${Math.max(revenuePercent, 3)}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Monthly Enrollment Breakdown Pills */}
                  <div className="pt-2 border-t border-slate-900 flex flex-wrap items-center gap-2">
                    <span className="text-[11px] text-slate-400 font-bold flex items-center space-x-1">
                      <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Monthly Purchases:</span>
                    </span>
                    {Object.entries(monthsBreakdown).map(([month, countVal]) => {
                      const count = Number(countVal);
                      return (
                        <span
                          key={month}
                          className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold flex items-center space-x-1.5 border ${
                            count > 0
                              ? 'bg-indigo-950/80 text-indigo-300 border-indigo-700/60'
                              : 'bg-slate-900 text-slate-500 border-slate-800'
                          }`}
                        >
                          <span>{month}:</span>
                          <span className={count > 0 ? 'text-emerald-400 font-bold' : 'text-slate-500'}>
                            {count} {count === 1 ? 'student' : 'students'}
                          </span>
                        </span>
                      );
                    })}
                  </div>

                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* SUB-TAB 2: REGISTERED ACCOUNTS LIST (EDIT / DELETE / CREATE) */}
      {activeSubTab === 'admin-users' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Create New Account Form */}
          <div className="lg:col-span-1 bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4 shadow-lg">
            <div className="flex items-center space-x-2 text-white border-b border-slate-800 pb-3">
              <UserPlus className="w-5 h-5 text-indigo-400" />
              <h2 className="text-base font-bold">Register New Account</h2>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Create a student or administrator user account directly into the database.
            </p>

            {adminFeedback && (
              <div
                className={`p-3.5 rounded-2xl text-xs font-semibold flex items-start space-x-2 ${
                  adminFeedback.type === 'success'
                    ? 'bg-emerald-950/80 text-emerald-200 border border-emerald-800'
                    : 'bg-rose-950/80 text-rose-200 border border-rose-800'
                }`}
              >
                {adminFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                )}
                <span>{adminFeedback.msg}</span>
              </div>
            )}

            <form onSubmit={handleCreateAdmin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Full Name <span className="text-rose-400">*</span>
                </label>
                <input
                  id="input-create-admin-name"
                  type="text"
                  required
                  placeholder="e.g. Kasun Kalhara"
                  value={newAdminName}
                  onChange={(e) => setNewAdminName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Email Address <span className="text-rose-400">*</span>
                </label>
                <input
                  id="input-create-admin-email"
                  type="email"
                  required
                  placeholder="e.g. kasun@lms.edu"
                  value={newAdminEmail}
                  onChange={(e) => setNewAdminEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Phone / Contact Number
                </label>
                <input
                  id="input-create-admin-phone"
                  type="text"
                  placeholder="+94 77 123 4567"
                  value={newAdminPhone}
                  onChange={(e) => setNewAdminPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Role Title / Description
                </label>
                <input
                  id="input-create-admin-bio"
                  type="text"
                  placeholder="Senior Administrator or 2026 A/L Student"
                  value={newAdminBio}
                  onChange={(e) => setNewAdminBio(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <button
                id="btn-submit-create-admin"
                type="submit"
                disabled={isSubmittingAdmin}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center justify-center space-x-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>{isSubmittingAdmin ? 'Registering Account...' : 'Register User Account'}</span>
              </button>
            </form>
          </div>

          {/* Registered User Accounts Directory */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-5 shadow-lg">
            
            {/* Header + Filter Bar */}
            <div className="space-y-3 border-b border-slate-800 pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h2 className="text-base font-bold text-white flex items-center space-x-2">
                    <Users className="w-5 h-5 text-indigo-400" />
                    <span>Registered Accounts List ({users.length})</span>
                  </h2>
                  <p className="text-xs text-slate-400">
                    Search, inspect, edit profile details, or delete accounts permanently.
                  </p>
                </div>

                {/* Role Filter Tabs */}
                <div className="flex items-center space-x-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0">
                  <button
                    onClick={() => setUserRoleFilter('all')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      userRoleFilter === 'all'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    All ({users.length})
                  </button>
                  <button
                    onClick={() => setUserRoleFilter('student')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      userRoleFilter === 'student'
                        ? 'bg-emerald-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Students ({users.filter(u => u.role === 'student').length})
                  </button>
                  <button
                    onClick={() => setUserRoleFilter('admin')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      userRoleFilter === 'admin'
                        ? 'bg-indigo-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Admins ({users.filter(u => u.role === 'admin').length})
                  </button>
                </div>
              </div>

              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="Search user by name, email, phone number, or ID..."
                  value={userSearchText}
                  onChange={(e) => setUserSearchText(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            {/* Users Cards List */}
            <div className="space-y-3">
              {filteredUsersList.length === 0 ? (
                <div className="p-8 text-center bg-slate-950 border border-slate-800 rounded-2xl text-slate-400 text-xs">
                  No registered accounts found matching your search query.
                </div>
              ) : (
                filteredUsersList.map((u) => {
                  const enrolledCount = u.enrolledMonthKeys?.length || 0;
                  const isUserAdmin = u.role === 'admin';

                  return (
                    <div
                      key={u.id}
                      className="p-4 rounded-2xl bg-slate-950 border border-slate-800/90 hover:border-slate-700 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="flex items-start space-x-3">
                        <img
                          src={u.avatar || (isUserAdmin
                            ? 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80'
                            : 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80')}
                          alt={u.name}
                          className="w-12 h-12 rounded-xl object-cover border border-slate-800 shrink-0 mt-0.5"
                        />
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-bold text-sm text-white">{u.name}</span>
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                                isUserAdmin
                                  ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                                  : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                              }`}
                            >
                              {isUserAdmin ? 'ADMINISTRATOR' : 'STUDENT'}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-400">
                            <span className="flex items-center space-x-1">
                              <Mail className="w-3.5 h-3.5 text-slate-500" />
                              <span>{u.email}</span>
                            </span>
                            {u.phone && (
                              <span className="flex items-center space-x-1">
                                <Phone className="w-3.5 h-3.5 text-slate-500" />
                                <span>{u.phone}</span>
                              </span>
                            )}
                          </div>

                          <div className="text-[11px] text-slate-500 flex items-center space-x-2">
                            <span>Bio: {u.bio || 'Registered user'}</span>
                            <span>•</span>
                            <span className="text-slate-400">ID: {u.id}</span>
                          </div>
                        </div>
                      </div>

                      {/* Right Action Controls */}
                      <div className="flex items-center justify-between md:justify-end gap-3 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-900">
                        <div className="text-left md:text-right text-[11px] text-slate-400 font-mono">
                          <div className="text-emerald-400 font-semibold">
                            {enrolledCount > 0 ? `${enrolledCount} Month Subscriptions` : 'No Active Subscriptions'}
                          </div>
                          <div className="text-slate-500 text-[10px]">
                            {isUserAdmin ? 'Full Admin Access' : 'Student Access'}
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          {/* Edit Button */}
                          <button
                            id={`btn-edit-user-${u.id}`}
                            onClick={() => handleOpenEditUser(u)}
                            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition-colors cursor-pointer flex items-center space-x-1 text-xs font-semibold"
                            title="Edit User Account"
                          >
                            <Edit2 className="w-3.5 h-3.5 text-indigo-400" />
                            <span>Edit</span>
                          </button>

                          {/* Delete Button */}
                          <button
                            id={`btn-delete-user-${u.id}`}
                            onClick={() => setDeletingUser(u)}
                            className="p-2 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/60 transition-colors cursor-pointer flex items-center space-x-1 text-xs font-semibold"
                            title="Delete User Account"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                            <span>Delete</span>
                          </button>
                        </div>
                      </div>

                    </div>
                  );
                })
              )}
            </div>

          </div>

        </div>
      )}

      {/* SUB-TAB 3: HOW DATABASE WORKS EXPLAINER */}
      {activeSubTab === 'database' && (
        <div className="bg-slate-900 border border-slate-800 p-6 sm:p-8 rounded-3xl space-y-8">
          
          <div className="flex items-center space-x-3 border-b border-slate-800 pb-4">
            <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-white">How Academia LMS Database & Data Architecture Works</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Technical guide on full-stack state management, payment authorization locks, and cloud database integration.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Step 1: Server State & Data Models */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center space-x-2 text-indigo-400 font-bold text-sm">
                <Server className="w-5 h-5" />
                <span>1. Express REST Backend & Schema</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                The application runs a <strong>Node.js Express backend (`server.ts`)</strong> serving structured JSON endpoints (`/api/courses`, `/api/payments`, `/api/users`).
              </p>
              <ul className="text-[11px] text-slate-400 space-y-1 list-disc pl-4">
                <li><strong className="text-slate-200">User Model:</strong> Stores role, enrolled course IDs, and monthly access keys (`enrolledMonthKeys`).</li>
                <li><strong className="text-slate-200">Course Model:</strong> Contains price, zoom sessions, video recordings, and active months.</li>
              </ul>
            </div>

            {/* Step 2: Payment Verification & Locks */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center space-x-2 text-amber-400 font-bold text-sm">
                <Key className="w-5 h-5" />
                <span>2. Monthly Access Authorization</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                When a student purchases monthly access (e.g. <em>August 2026 Physics</em>):
              </p>
              <ul className="text-[11px] text-slate-400 space-y-1 list-disc pl-4">
                <li><strong className="text-slate-200">Instant Card:</strong> Unlocks `courseId_month` key immediately.</li>
                <li><strong className="text-slate-200">Bank Transfer:</strong> Generates a pending transaction for admin slip verification.</li>
                <li><strong className="text-slate-200">Approval:</strong> Upon admin approval, the server pushes `courseId_month` to `user.enrolledMonthKeys`.</li>
              </ul>
            </div>

            {/* Step 3: Cloud Database Migration */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center space-x-2 text-emerald-400 font-bold text-sm">
                <Layers className="w-5 h-5" />
                <span>3. Production Cloud DB Ready</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Designed for seamless transition to cloud persistence without refactoring frontend components:
              </p>
              <ul className="text-[11px] text-slate-400 space-y-1 list-disc pl-4">
                <li><strong className="text-slate-200">Firebase Firestore:</strong> Sync collections `courses`, `users`, and `payments`.</li>
                <li><strong className="text-slate-200">PostgreSQL / Cloud SQL:</strong> Compatible with Drizzle/Prisma relational tables.</li>
              </ul>
            </div>

          </div>

          {/* Database Code Architecture Visual Schema */}
          <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800/90 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between text-slate-300 font-sans font-bold text-sm border-b border-slate-800 pb-2">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <span>Live Data Access Key Schema</span>
              </div>
              <span className="text-[11px] text-emerald-400">Server Status: Connected</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 space-y-2 overflow-x-auto">
              <div className="text-indigo-300">// Example User Schema with Month Keys</div>
              <div>{`{`}</div>
              <div className="pl-4 text-emerald-300">"id": "usr-1722556800",</div>
              <div className="pl-4">"name": "Kamal Perera",</div>
              <div className="pl-4">"email": "student@lms.edu",</div>
              <div className="pl-4 text-amber-300">"enrolledMonthKeys": [</div>
              <div className="pl-8 text-sky-300">"course-physics-al_July 2026",</div>
              <div className="pl-8 text-sky-300">"course-physics-al_August 2026",</div>
              <div className="pl-8 text-sky-300">"course-chemistry-al_August 2026"</div>
              <div className="pl-4 text-amber-300">]</div>
              <div>{`}`}</div>
            </div>
          </div>

        </div>
      )}

      {/* Quick Admin Navigation Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        <div
          onClick={() => onNavigateTab('admin-payments')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-5 rounded-3xl space-y-3 cursor-pointer transition-all"
        >
          <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-300 w-fit">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-white">Payment Approvals Queue</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Review bank slip receipts, verify wire numbers, and grant monthly access with 1 click.
          </p>
        </div>

        <div
          onClick={() => onNavigateTab('admin-courses')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-5 rounded-3xl space-y-3 cursor-pointer transition-all"
        >
          <div className="p-2.5 rounded-2xl bg-indigo-500/20 text-indigo-400 w-fit">
            <BookOpen className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-white">Course Management</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Create new courses, edit tuition fees, set category tags, instructor details, and syllabus.
          </p>
        </div>

        <div
          onClick={() => onNavigateTab('admin-zoom')}
          className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-5 rounded-3xl space-y-3 cursor-pointer transition-all"
        >
          <div className="p-2.5 rounded-2xl bg-sky-500/20 text-sky-400 w-fit">
            <Video className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-white">Zoom & Video Recordings</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Update Zoom meeting links, meeting IDs, passcodes, and upload HD lecture recordings per month.
          </p>
        </div>

      </div>

      {/* EDIT USER ACCOUNT MODAL */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <form
            onSubmit={handleSaveEditUser}
            className="relative max-w-lg w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Edit2 className="w-4 h-4 text-indigo-400" />
                <h3 className="font-bold text-sm text-white">Edit Registered User Account</h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-1">
              <div className="flex justify-between font-mono text-[11px]">
                <span>User ID: <strong className="text-slate-200">{editingUser.id}</strong></span>
                <span>Created: <strong className="text-slate-200">{new Date(editingUser.createdAt || Date.now()).toLocaleDateString()}</strong></span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editUserName}
                  onChange={(e) => setEditUserName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={editUserEmail}
                  onChange={(e) => setEditUserEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Account Role</label>
                <select
                  value={editUserRole}
                  onChange={(e) => setEditUserRole(e.target.value as 'student' | 'admin')}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="student">Student Account</option>
                  <option value="admin">Administrator Account</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Phone Number</label>
                <input
                  type="text"
                  value={editUserPhone}
                  onChange={(e) => setEditUserPhone(e.target.value)}
                  placeholder="+94 77 123 4567"
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Bio / Role Description</label>
              <textarea
                rows={2}
                value={editUserBio}
                onChange={(e) => setEditUserBio(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="flex items-center justify-end space-x-3 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSavingUser}
                className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center space-x-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{isSavingUser ? 'Saving Changes...' : 'Save User Account'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* DELETE USER CONFIRMATION MODAL */}
      {deletingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative max-w-md w-full bg-slate-900 border border-rose-800/60 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center space-x-2 text-rose-400">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <h3 className="font-bold text-sm text-white">Permanently Delete Account?</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to delete the registered account for <strong className="text-white">{deletingUser.name}</strong> (<span className="text-indigo-300">{deletingUser.email}</span>)?
            </p>
            <p className="text-[11px] text-rose-400 bg-rose-950/40 p-3 rounded-xl border border-rose-800/40">
              ⚠️ Warning: This action will permanently remove this user account from the LMS database.
            </p>

            <div className="flex items-center justify-end space-x-3 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeletingUser(null)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeletingUser}
                onClick={handleConfirmDeleteUser}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-bold text-xs shadow-md transition-all cursor-pointer flex items-center space-x-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isDeletingUser ? 'Deleting Account...' : 'Confirm & Delete'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

import React, { useState } from 'react';
import { PaymentTransaction } from '../../types';
import { CreditCard, CheckCircle2, XCircle, Clock, ExternalLink, ShieldCheck, Eye, Search } from 'lucide-react';

interface AdminPaymentApprovalsProps {
  payments: PaymentTransaction[];
  onApprove: (paymentId: string) => void;
  onReject: (paymentId: string, reason: string) => void;
}

export const AdminPaymentApprovals: React.FC<AdminPaymentApprovalsProps> = ({
  payments,
  onApprove,
  onReject,
}) => {
  const [filter, setFilter] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPaymentForReceipt, setSelectedPaymentForReceipt] = useState<PaymentTransaction | null>(null);
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  const filteredPayments = payments.filter((p) => {
    const matchesFilter = filter === 'all' || p.status === filter;
    const matchesSearch =
      p.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.userEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.courseTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.referenceCode.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const pendingCount = payments.filter(p => p.status === 'pending').length;

  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectingId) return;
    onReject(rejectingId, rejectReason || 'Receipt verification failed.');
    setRejectingId(null);
    setRejectReason('');
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl space-y-2">
        <div className="flex items-center space-x-2 text-xs font-semibold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full w-fit">
          <Clock className="w-3.5 h-3.5" />
          <span>Payment Verification Center</span>
        </div>
        <h1 className="text-3xl font-extrabold text-white tracking-tight">Student Payment Approvals</h1>
        <p className="text-xs sm:text-sm text-slate-300">
          Review student tuition receipts, verify bank transfer reference codes, and approve access to live Zoom classes and recordings.
        </p>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          
          <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              id="filter-pay-pending"
              onClick={() => setFilter('pending')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all relative ${
                filter === 'pending'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>Pending Approvals</span>
              {pendingCount > 0 && (
                <span className="ml-1 px-1.5 py-0.5 text-[10px] bg-slate-900 text-amber-300 rounded-full font-bold">
                  {pendingCount}
                </span>
              )}
            </button>

            <button
              id="filter-pay-approved"
              onClick={() => setFilter('approved')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                filter === 'approved'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Approved ({payments.filter(p => p.status === 'approved').length})
            </button>

            <button
              id="filter-pay-rejected"
              onClick={() => setFilter('rejected')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                filter === 'rejected'
                  ? 'bg-rose-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Rejected ({payments.filter(p => p.status === 'rejected').length})
            </button>

            <button
              id="filter-pay-all"
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                filter === 'all'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All Records
            </button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-500" />
            <input
              id="input-search-payments"
              type="text"
              placeholder="Search student, email, ref #..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-64 pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

        </div>
      </div>

      {/* Transactions Queue List */}
      {filteredPayments.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-xs text-slate-500 space-y-2">
          <div>No transactions found matching the current filter.</div>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPayments.map((pay) => (
            <div
              key={pay.id}
              className={`p-6 rounded-3xl border transition-all ${
                pay.status === 'pending'
                  ? 'bg-slate-900 border-amber-500/40 shadow-xl'
                  : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
                
                {/* Left Student & Course Info */}
                <div className="space-y-2 flex-1">
                  <div className="flex items-center space-x-3">
                    <img
                      src={pay.userAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
                      alt={pay.userName}
                      className="w-10 h-10 rounded-xl object-cover border border-slate-700"
                    />
                    <div>
                      <div className="font-bold text-sm text-white flex items-center space-x-2">
                        <span>{pay.userName}</span>
                        <span className="text-xs text-slate-400 font-normal">({pay.userEmail})</span>
                      </div>
                      <div className="text-xs text-indigo-300 font-semibold">
                        Course: {pay.courseTitle}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
                    <span>Reference: <code className="text-amber-300 font-mono">{pay.referenceCode}</code></span>
                    <span>Method: <strong className="capitalize text-slate-200">{pay.paymentMethod.replace('_', ' ')}</strong></span>
                    <span>Submitted: {new Date(pay.createdAt).toLocaleString()}</span>
                  </div>

                  {pay.note && (
                    <div className="text-xs text-slate-300 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                      <strong>Student Note:</strong> {pay.note}
                    </div>
                  )}
                </div>

                {/* Right Receipt & Approval Actions */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 shrink-0 w-full lg:w-auto">
                  
                  {/* Receipt Thumbnail & Inspection Trigger */}
                  {pay.receiptUrl ? (
                    <div
                      onClick={() => setSelectedPaymentForReceipt(pay)}
                      className="group relative cursor-pointer border border-slate-700 hover:border-indigo-500 rounded-2xl overflow-hidden bg-slate-950 p-1 transition-all flex items-center space-x-2 shrink-0"
                    >
                      <img
                        src={pay.receiptUrl}
                        alt="Receipt Proof"
                        className="w-14 h-14 object-cover rounded-xl border border-slate-800 group-hover:scale-105 transition-transform"
                      />
                      <div className="pr-2">
                        <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider flex items-center space-x-1">
                          <Eye className="w-3 h-3" />
                          <span>Inspect Proof</span>
                        </div>
                        <div className="text-[11px] text-slate-300 font-medium">Click to Zoom Slip</div>
                      </div>
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-500 italic">No receipt image attached</span>
                  )}

                  <div className="text-right">
                    <div className="text-xl font-black text-white">Rs. {pay.amount.toLocaleString()}</div>
                  </div>

                  {pay.status === 'pending' ? (
                    <div className="flex items-center space-x-2">
                      <button
                        id={`btn-approve-payment-${pay.id}`}
                        onClick={() => onApprove(pay.id)}
                        className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 transition-all flex items-center space-x-1.5 cursor-pointer min-h-[44px]"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Approve & Unlock</span>
                      </button>

                      <button
                        id={`btn-reject-payment-${pay.id}`}
                        onClick={() => setRejectingId(pay.id)}
                        className="px-3 py-2.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 font-semibold text-xs transition-colors cursor-pointer min-h-[44px]"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </div>
                  ) : pay.status === 'approved' ? (
                    <span className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30 flex items-center space-x-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Approved</span>
                    </span>
                  ) : (
                    <span className="px-3.5 py-1.5 rounded-xl bg-rose-500/20 text-rose-300 text-xs font-bold border border-rose-500/30">
                      Rejected
                    </span>
                  )}

                </div>

              </div>
            </div>
          ))}
        </div>
      )}

      {/* Receipt Image Inspection Modal */}
      {selectedPaymentForReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
          <div className="relative max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-5 h-5 text-indigo-400" />
                <h3 className="font-extrabold text-base text-white">Student Bank Receipt Verification</h3>
              </div>
              <button
                id="btn-close-receipt-modal"
                onClick={() => setSelectedPaymentForReceipt(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Student details header in receipt modal */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div>
                <div className="font-bold text-white text-sm">{selectedPaymentForReceipt.userName} ({selectedPaymentForReceipt.userEmail})</div>
                <div className="text-indigo-300 font-semibold">{selectedPaymentForReceipt.courseTitle}</div>
                <div className="text-slate-400 mt-0.5">Reference Code: <code className="text-amber-300 font-mono font-bold">{selectedPaymentForReceipt.referenceCode}</code></div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-2xl font-black text-emerald-400">Rs. {selectedPaymentForReceipt.amount.toLocaleString()}</div>
                <div className="text-[10px] text-slate-400">Status: <span className="uppercase font-bold text-amber-300">{selectedPaymentForReceipt.status}</span></div>
              </div>
            </div>

            {/* High-Resolution Receipt Image Proof Container */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-slate-300 flex items-center justify-between">
                <span>Submitted Receipt Slip Image Proof:</span>
                {selectedPaymentForReceipt.receiptUrl && (
                  <a
                    href={selectedPaymentForReceipt.receiptUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-indigo-400 hover:underline flex items-center space-x-1 text-[11px]"
                  >
                    <span>Open Full Image</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
              
              <div className="p-2 rounded-2xl bg-slate-950 border border-slate-800 max-h-[450px] overflow-auto flex items-center justify-center">
                <img
                  src={selectedPaymentForReceipt.receiptUrl || 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80'}
                  alt="Receipt Proof"
                  className="w-full max-h-[420px] object-contain rounded-xl border border-slate-800"
                />
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedPaymentForReceipt(null)}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 transition-colors"
              >
                Close Inspection
              </button>

              {selectedPaymentForReceipt.status === 'pending' && (
                <div className="flex items-center space-x-2 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => {
                      onReject(selectedPaymentForReceipt.id, 'Invalid receipt slip image.');
                      setSelectedPaymentForReceipt(null);
                    }}
                    className="w-1/2 sm:w-auto px-4 py-2.5 rounded-xl bg-rose-600/20 text-rose-300 border border-rose-500/30 text-xs font-bold hover:bg-rose-600/30"
                  >
                    Reject Slip
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onApprove(selectedPaymentForReceipt.id);
                      setSelectedPaymentForReceipt(null);
                    }}
                    className="w-1/2 sm:w-auto px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center space-x-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Approve Receipt & Unlock</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {rejectingId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <form onSubmit={handleConfirmReject} className="relative max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <h3 className="font-bold text-sm text-white">Reject Payment Transaction</h3>
            <p className="text-xs text-slate-400">
              Please enter a brief explanation for the student regarding why the receipt could not be approved.
            </p>
            <input
              id="input-reject-reason"
              type="text"
              required
              placeholder="e.g. Reference code does not match bank records."
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-rose-500"
            />
            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setRejectingId(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold"
              >
                Confirm Rejection
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};

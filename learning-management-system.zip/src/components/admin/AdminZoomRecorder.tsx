import React, { useState } from 'react';
import { Course, ZoomSession, VideoRecording } from '../../types';
import { Video, Play, Plus, Trash2, Calendar, Clock, Lock, ExternalLink, FileText, X, Upload, Youtube, Edit2, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface AdminZoomRecorderProps {
  courses: Course[];
  onAddZoomSession: (courseId: string, sessionData: Partial<ZoomSession>) => void;
  onUpdateZoomSession?: (courseId: string, sessionId: string, sessionData: Partial<ZoomSession>) => void;
  onDeleteZoomSession: (courseId: string, sessionId: string) => void;
  onAddRecording: (courseId: string, recData: Partial<VideoRecording>) => void;
  onUpdateRecording?: (courseId: string, recId: string, recData: Partial<VideoRecording>) => void;
  onDeleteRecording: (courseId: string, recId: string) => void;
}

export const AdminZoomRecorder: React.FC<AdminZoomRecorderProps> = ({
  courses,
  onAddZoomSession,
  onUpdateZoomSession,
  onDeleteZoomSession,
  onAddRecording,
  onUpdateRecording,
  onDeleteRecording,
}) => {
  const [selectedCourseId, setSelectedCourseId] = useState<string>(courses[0]?.id || '');
  const [selectedMonth, setSelectedMonth] = useState<string>('August 2026');

  const activeCourse = courses.find(c => c.id === selectedCourseId) || courses[0];

  // Zoom Form State
  const [showZoomModal, setShowZoomModal] = useState(false);
  const [editingZoomSessionId, setEditingZoomSessionId] = useState<string | null>(null);
  const [zoomMonth, setZoomMonth] = useState('August 2026');
  const [zoomTitle, setZoomTitle] = useState('Live Theory & Problem Solving Session');
  const [zoomUrl, setZoomUrl] = useState('https://zoom.us/j/98765432100?pwd=AcademiaLMS2026');
  const [meetingId, setMeetingId] = useState('987 6543 2100');
  const [passcode, setPasscode] = useState('440192');
  const [scheduledAt, setScheduledAt] = useState(new Date(Date.now() + 1000 * 60 * 60 * 24).toISOString().slice(0, 16));
  const [durationMinutes, setDurationMinutes] = useState('90');
  const [zoomStatus, setZoomStatus] = useState<'upcoming' | 'live' | 'ended'>('upcoming');

  // Recording Form State
  const [showRecModal, setShowRecModal] = useState(false);
  const [editingRecordingId, setEditingRecordingId] = useState<string | null>(null);
  const [recMonth, setRecMonth] = useState('August 2026');
  const [recTitle, setRecTitle] = useState('Lecture Module: Core Concepts & Worked Examples');
  const [recUrl, setRecUrl] = useState('https://www.youtube.com/watch?v=1S0aBV-Waeo');
  const [recChapter, setRecChapter] = useState('August Unit 1');
  const [recDuration, setRecDuration] = useState('50 mins');
  const [recDescription, setRecDescription] = useState('Detailed video lecture covering fundamental theory and past paper exercises.');

  const handleOpenAddZoom = () => {
    setEditingZoomSessionId(null);
    setZoomMonth('August 2026');
    setZoomTitle('Live Theory & Problem Solving Session');
    setZoomUrl('https://zoom.us/j/98765432100?pwd=AcademiaLMS2026');
    setMeetingId('987 6543 2100');
    setPasscode('440192');
    setScheduledAt(new Date(Date.now() + 1000 * 60 * 60 * 24 * 30).toISOString().slice(0, 16)); // set 30 days ahead default so it doesn't expire quickly
    setDurationMinutes('90');
    setZoomStatus('upcoming');
    setShowZoomModal(true);
  };

  const handleOpenEditZoom = (session: ZoomSession) => {
    setEditingZoomSessionId(session.id);
    setZoomMonth(session.month || 'August 2026');
    setZoomTitle(session.title);
    setZoomUrl(session.zoomUrl);
    setMeetingId(session.meetingId);
    setPasscode(session.passcode);
    try {
      setScheduledAt(new Date(session.scheduledAt).toISOString().slice(0, 16));
    } catch {
      setScheduledAt(new Date().toISOString().slice(0, 16));
    }
    setDurationMinutes(String(session.durationMinutes));
    setZoomStatus(session.status);
    setShowZoomModal(true);
  };

  const handleOpenAddRec = () => {
    setEditingRecordingId(null);
    setRecMonth('August 2026');
    setRecTitle('Lecture Module: Core Concepts & Worked Examples');
    setRecUrl('https://www.youtube.com/watch?v=1S0aBV-Waeo');
    setRecChapter('August Unit 1');
    setRecDuration('50 mins');
    setRecDescription('Detailed video lecture covering fundamental theory and past paper exercises.');
    setShowRecModal(true);
  };

  const handleOpenEditRec = (rec: VideoRecording) => {
    setEditingRecordingId(rec.id);
    setRecMonth(rec.month || 'August 2026');
    setRecTitle(rec.title);
    setRecUrl(rec.videoUrl);
    setRecChapter(rec.chapter);
    setRecDuration(rec.duration);
    setRecDescription(rec.description || '');
    setShowRecModal(true);
  };

  const handleVideoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setRecUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveZoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCourse) return;

    const payload: Partial<ZoomSession> = {
      month: zoomMonth,
      title: zoomTitle,
      zoomUrl,
      meetingId,
      passcode,
      scheduledAt: new Date(scheduledAt).toISOString(),
      durationMinutes: Number(durationMinutes),
      status: zoomStatus,
    };

    if (editingZoomSessionId && onUpdateZoomSession) {
      onUpdateZoomSession(activeCourse.id, editingZoomSessionId, payload);
    } else {
      onAddZoomSession(activeCourse.id, payload);
    }
    setShowZoomModal(false);
    setEditingZoomSessionId(null);
  };

  const handleSaveRecording = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCourse) return;

    const payload: Partial<VideoRecording> = {
      month: recMonth,
      title: recTitle,
      videoUrl: recUrl,
      chapter: recChapter,
      duration: recDuration,
      description: recDescription,
    };

    if (editingRecordingId && onUpdateRecording) {
      onUpdateRecording(activeCourse.id, editingRecordingId, payload);
    } else {
      onAddRecording(activeCourse.id, payload);
    }
    setShowRecModal(false);
    setEditingRecordingId(null);
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-8 rounded-3xl">
        <div className="space-y-1">
          <div className="flex items-center space-x-2 text-xs font-semibold text-sky-400 bg-sky-500/10 border border-sky-500/30 px-3 py-1 rounded-full w-fit">
            <Video className="w-3.5 h-3.5" />
            <span>Zoom Links & Video Recordings Manager</span>
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Live Classes & Video Control</h1>
          <p className="text-xs text-slate-400">Update Zoom URLs, Meeting IDs, Passcodes, and attach video recordings.</p>
        </div>

        {/* Course Selector Dropdown */}
        {courses.length > 0 && (
          <div className="w-full sm:w-auto">
            <label className="block text-[11px] font-semibold text-slate-400 mb-1">Select Course to Manage:</label>
            <select
              id="select-admin-zoom-course"
              value={selectedCourseId}
              onChange={(e) => setSelectedCourseId(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs font-bold text-white focus:outline-none focus:border-indigo-500 cursor-pointer shadow-lg"
            >
              {courses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {activeCourse && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Zoom Live Sessions Manager Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-2">
                <Video className="w-5 h-5 text-sky-400" />
                <h3 className="font-bold text-base text-white">Zoom Live Sessions</h3>
              </div>
              <button
                id="btn-admin-add-zoom"
                onClick={handleOpenAddZoom}
                className="px-3.5 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-md shadow-sky-600/20 transition-all flex items-center space-x-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Zoom Session</span>
              </button>
            </div>

            {activeCourse.zoomSessions.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500">
                No Zoom sessions configured yet for this course.
              </div>
            ) : (
              <div className="space-y-3">
                {activeCourse.zoomSessions.map((session) => (
                  <div key={session.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        session.status === 'live' ? 'bg-rose-600 text-white animate-pulse' : 'bg-sky-500/20 text-sky-300'
                      }`}>
                        {session.status.toUpperCase()}
                      </span>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleOpenEditZoom(session)}
                          className="p-1.5 rounded-lg text-sky-400 hover:text-sky-300 hover:bg-sky-950/60 transition-colors cursor-pointer"
                          title="Edit Class & Link"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteZoomSession(activeCourse.id, session.id)}
                          className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/60 transition-colors cursor-pointer"
                          title="Delete Session"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h4 className="font-bold text-xs text-white">{session.title}</h4>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Meeting ID: {session.meetingId} | Passcode: {session.passcode}
                    </div>
                    <div className="text-[11px] text-sky-300 truncate font-mono bg-slate-900 px-2 py-1 rounded border border-slate-800">
                      {session.zoomUrl}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Video Recordings Manager Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center space-x-2">
                <Play className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base text-white">Video Recordings</h3>
              </div>
              <button
                id="btn-admin-add-rec"
                onClick={handleOpenAddRec}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center space-x-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Upload Recording</span>
              </button>
            </div>

            {activeCourse.recordings.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500">
                No video recordings attached yet for this course.
              </div>
            ) : (
              <div className="space-y-3">
                {activeCourse.recordings.map((rec) => (
                  <div key={rec.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-emerald-400 uppercase">
                        {rec.chapter}
                      </span>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleOpenEditRec(rec)}
                          className="p-1.5 rounded-lg text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/60 transition-colors cursor-pointer"
                          title="Edit Video Recording"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => onDeleteRecording(activeCourse.id, rec.id)}
                          className="p-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-950/60 transition-colors cursor-pointer"
                          title="Delete Recording"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h4 className="font-bold text-xs text-white">{rec.title}</h4>
                    <p className="text-[11px] text-slate-400">{rec.description}</p>
                    <div className="text-[10px] text-slate-500 font-mono truncate bg-slate-900 px-2 py-1 rounded border border-slate-800">
                      {rec.videoUrl}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}

      {/* Zoom Session Add / Edit Modal */}
      {showZoomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <form onSubmit={handleSaveZoom} className="relative max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Video className="w-4 h-4 text-sky-400" />
                <h3 className="font-bold text-sm text-white">
                  {editingZoomSessionId ? 'Edit Zoom Class & Link' : 'Add New Zoom Meeting Link'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowZoomModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-2.5 rounded-xl bg-sky-950/40 border border-sky-800/40 text-[11px] text-sky-300 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0" />
              <span>Database Sync Active: Saved Zoom links update permanently in database for all students.</span>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Target Subscription Month</label>
              <select
                id="select-zoom-month"
                value={zoomMonth}
                onChange={(e) => setZoomMonth(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500 font-bold"
              >
                {(activeCourse.availableMonths || ['July 2026', 'August 2026', 'September 2026', 'October 2026', 'November 2026', 'December 2026']).map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Session Title</label>
              <input
                id="input-zoom-title"
                type="text"
                required
                value={zoomTitle}
                onChange={(e) => setZoomTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Zoom Meeting Join URL</label>
              <input
                id="input-zoom-url"
                type="text"
                required
                value={zoomUrl}
                onChange={(e) => setZoomUrl(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Meeting ID</label>
                <input
                  id="input-zoom-meeting-id"
                  type="text"
                  required
                  value={meetingId}
                  onChange={(e) => setMeetingId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Passcode</label>
                <input
                  id="input-zoom-passcode"
                  type="text"
                  required
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Schedule Date & Time</label>
                <input
                  id="input-zoom-datetime"
                  type="datetime-local"
                  required
                  value={scheduledAt}
                  onChange={(e) => setScheduledAt(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Status</label>
                <select
                  id="select-zoom-status"
                  value={zoomStatus}
                  onChange={(e) => setZoomStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-sky-500"
                >
                  <option value="upcoming">Upcoming</option>
                  <option value="live">Live Now</option>
                  <option value="ended">Ended</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowZoomModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                id="btn-save-zoom-session"
                type="submit"
                className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs"
              >
                Save Zoom Class
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Recording Add / Edit Modal */}
      {showRecModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <form onSubmit={handleSaveRecording} className="relative max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <Play className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-sm text-white">
                  {editingRecordingId ? 'Edit Video Recording Details' : 'Attach Lecture Video Recording'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowRecModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-[11px] text-emerald-300 flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Database Sync Active: Video recordings update permanently for enrolled students.</span>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Target Subscription Month</label>
              <select
                id="select-rec-month"
                value={recMonth}
                onChange={(e) => setRecMonth(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-emerald-500 font-bold"
              >
                {(activeCourse.availableMonths || ['July 2026', 'August 2026', 'September 2026', 'October 2026', 'November 2026', 'December 2026']).map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Recording Title</label>
              <input
                id="input-rec-title"
                type="text"
                required
                value={recTitle}
                onChange={(e) => setRecTitle(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] text-slate-400">Video Link (YouTube URL or MP4 File)</label>
                <div className="flex items-center space-x-1.5">
                  <button
                    type="button"
                    onClick={() => setRecUrl('https://www.youtube.com/watch?v=1S0aBV-Waeo')}
                    className="text-[10px] text-red-400 hover:text-red-300 font-bold px-1.5 py-0.5 rounded bg-red-950/60 border border-red-800/60 flex items-center space-x-1 cursor-pointer"
                  >
                    <Youtube className="w-3 h-3" />
                    <span>YouTube Sample</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setRecUrl('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4')}
                    className="text-[10px] text-emerald-400 hover:text-emerald-300 font-bold px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/60 flex items-center space-x-1 cursor-pointer"
                  >
                    <Play className="w-3 h-3" />
                    <span>MP4 Sample</span>
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <input
                    id="input-rec-url"
                    type="text"
                    required
                    value={recUrl}
                    placeholder="https://www.youtube.com/watch?v=... OR https://.../file.mp4"
                    onChange={(e) => setRecUrl(e.target.value)}
                    className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-emerald-500 font-mono"
                  />
                  <label className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center space-x-1.5 cursor-pointer shrink-0 transition-colors">
                    <Upload className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Upload Video</span>
                    <input
                      id="input-file-rec-upload"
                      type="file"
                      accept="video/*"
                      onChange={handleVideoFileUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <div className="text-[10px] text-slate-500">
                  Paste YouTube link (<span className="text-slate-400">youtube.com</span> or <span className="text-slate-400">youtu.be</span>), direct <span className="text-slate-400">.mp4</span> link, or upload a local video file.
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Chapter Tag</label>
                <input
                  id="input-rec-chapter"
                  type="text"
                  required
                  value={recChapter}
                  onChange={(e) => setRecChapter(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Duration</label>
                <input
                  id="input-rec-duration"
                  type="text"
                  required
                  value={recDuration}
                  onChange={(e) => setRecDuration(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Description</label>
              <textarea
                id="input-rec-desc"
                rows={2}
                value={recDescription}
                onChange={(e) => setRecDescription(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowRecModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                id="btn-save-recording"
                type="submit"
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs"
              >
                Save Video Recording
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};

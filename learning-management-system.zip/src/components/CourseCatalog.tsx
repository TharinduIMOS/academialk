import React, { useState } from 'react';
import { Course, User, PaymentTransaction } from '../types';
import { Search, Star, Clock, Video, User as UserIcon, CheckCircle2, ShieldAlert, Sparkles, Filter, ArrowRight } from 'lucide-react';

interface CourseCatalogProps {
  courses: Course[];
  user: User | null;
  payments: PaymentTransaction[];
  onSelectCourse: (course: Course) => void;
  onPurchaseCourse: (course: Course) => void;
  onOpenAuth: () => void;
}

export const CourseCatalog: React.FC<CourseCatalogProps> = ({
  courses,
  user,
  payments,
  onSelectCourse,
  onPurchaseCourse,
  onOpenAuth,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBatch, setSelectedBatch] = useState<string>('All');
  const [selectedLevel, setSelectedLevel] = useState<string>('All');

  const categories = ['All', ...Array.from(new Set(courses.map(c => c.category).filter(Boolean) as string[]))];
  const batches = ['All', ...Array.from(new Set(courses.map(c => c.batch).filter(Boolean) as string[]))];
  const levels = ['All', ...Array.from(new Set(courses.map(c => c.level).filter(Boolean) as string[]))];

  const filteredCourses = courses.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.batch && c.batch.toLowerCase().includes(searchQuery.toLowerCase())) ||
      c.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === 'All' || c.category === selectedCategory;
    const matchesBatch = selectedBatch === 'All' || c.batch === selectedBatch;
    const matchesLevel = selectedLevel === 'All' || c.level === selectedLevel;

    return matchesSearch && matchesCategory && matchesBatch && matchesLevel;
  });

  // Check enrollment status for current user
  const getUserCourseStatus = (courseId: string) => {
    if (!user) return 'unauthorized';
    if (user.role === 'admin') return 'admin';
    if (user.enrolledCourseIds.includes(courseId)) return 'enrolled';

    // Check pending payment
    const pendingPayment = payments.find(p => p.userId === user.id && p.courseId === courseId && p.status === 'pending');
    if (pendingPayment) return 'pending';

    return 'available';
  };

  return (
    <div className="space-y-8 pb-12">
      
      {/* Hero Header Section */}
      <div className="relative rounded-3xl bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-800 border border-indigo-500/20 p-8 sm:p-10 overflow-hidden shadow-xl shadow-indigo-100">
        <div className="absolute right-0 top-0 w-96 h-96 bg-white/10 rounded-full blur-3xl -mr-20 -mt-20 pointer-events-none"></div>
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/15 border border-white/20 text-indigo-100 text-xs font-semibold backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
            <span>Interactive Live Zoom & Recorded Video Platform</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
            Accelerate Your Skills with Live Classes & High-Definition Recordings
          </h1>
          <p className="text-sm sm:text-base text-indigo-100 leading-relaxed">
            Purchase live courses, attend interactive Zoom sessions with top instructors, and access on-demand video recordings anytime.
          </p>
          
          <div className="flex flex-wrap items-center gap-4 pt-2">
            {!user && (
              <button
                id="hero-btn-join"
                onClick={onOpenAuth}
                className="px-5 py-2.5 rounded-xl bg-white hover:bg-indigo-50 text-indigo-700 font-extrabold text-xs shadow-md transition-all flex items-center space-x-2 cursor-pointer"
              >
                <span>Student Sign In / Register</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
            <div className="flex items-center space-x-4 text-xs text-indigo-100 border-l border-indigo-400/40 pl-4 hidden sm:flex">
              <div><strong className="text-white">100% Verified</strong> Zoom Links</div>
              <div><strong className="text-white">Instant / Bank</strong> Approval</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
            <input
              id="input-search-courses"
              type="text"
              placeholder="Search courses by keyword, instructor, or topic..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600 focus:bg-white transition-all"
            />
          </div>

          {/* Batch Filter Dropdown */}
          <div className="flex items-center space-x-2 shrink-0">
            <Filter className="w-4 h-4 text-indigo-600" />
            <span className="text-xs text-slate-600 font-medium hidden sm:inline">Batch / Year:</span>
            <select
              id="select-batch-filter"
              value={selectedBatch}
              onChange={(e) => setSelectedBatch(e.target.value)}
              className="px-3 py-2 bg-indigo-50/80 border border-indigo-200 text-indigo-900 rounded-xl text-xs focus:outline-none focus:border-indigo-600 cursor-pointer font-bold"
            >
              {batches.map(b => (
                <option key={b} value={b}>{b === 'All' ? 'All Batches (2026 & 2027)' : b}</option>
              ))}
            </select>
          </div>

          {/* Level Filter Dropdown */}
          <div className="flex items-center space-x-2 shrink-0">
            <span className="text-xs text-slate-600 font-medium hidden sm:inline">Level:</span>
            <select
              id="select-level-filter"
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 focus:outline-none focus:border-indigo-600 cursor-pointer font-medium"
            >
              {levels.map(l => (
                <option key={l} value={l}>{l}</option>
              ))}
            </select>
          </div>

        </div>

        {/* Category Pills */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              id={`cat-filter-${cat.toLowerCase().replace(' ', '-')}`}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200/80 hover:bg-slate-200/60'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Course Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map((course) => {
          const status = getUserCourseStatus(course.id);
          const hasLiveZoom = course.zoomSessions.some(s => s.status === 'live');

          return (
            <div
              key={course.id}
              className="group bg-white border border-slate-200 hover:border-slate-300 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Course Thumbnail Container */}
                <div className="relative h-48 w-full overflow-hidden bg-slate-100">
                  <img
                    src={course.image}
                    alt={course.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent opacity-60"></div>
                  
                  {/* Category & Batch Pills */}
                  <div className="absolute top-3 left-3 flex items-center space-x-1.5 z-10">
                    <span className="px-2.5 py-1 rounded-lg bg-white/95 backdrop-blur-md border border-slate-200/80 text-xs font-bold text-indigo-700 shadow-xs">
                      {course.category}
                    </span>
                    {course.batch && (
                      <span className={`px-2.5 py-1 rounded-lg backdrop-blur-md text-xs font-extrabold text-white shadow-xs ${
                        course.batch === '2027 A/L' ? 'bg-purple-600/90' : 'bg-emerald-600/90'
                      }`}>
                        {course.batch}
                      </span>
                    )}
                  </div>

                  {/* Live Zoom Badge */}
                  {hasLiveZoom && (
                    <div className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-rose-600 text-white text-[11px] font-bold flex items-center space-x-1 shadow-xs animate-pulse">
                      <Video className="w-3.5 h-3.5" />
                      <span>ZOOM LIVE NOW</span>
                    </div>
                  )}

                  {/* Rating Badge */}
                  <div className="absolute bottom-3 left-3 flex items-center space-x-1 bg-white/95 backdrop-blur-md px-2 py-0.5 rounded-md text-xs font-bold text-slate-800 border border-slate-200/80 shadow-xs">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{course.rating}</span>
                    <span className="text-slate-500 font-normal">({course.reviewsCount})</span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 space-y-3">
                  <h3 
                    onClick={() => onSelectCourse(course)}
                    className="font-bold text-slate-900 text-base leading-snug group-hover:text-indigo-600 cursor-pointer transition-colors line-clamp-2"
                  >
                    {course.title}
                  </h3>

                  <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                    {course.description}
                  </p>

                  {/* Metadata */}
                  <div className="grid grid-cols-2 gap-2 py-2 border-y border-slate-100 text-[11px] text-slate-600">
                    <div className="flex items-center space-x-1.5">
                      <UserIcon className="w-3.5 h-3.5 text-indigo-600" />
                      <span className="truncate">{course.instructor}</span>
                    </div>
                    <div className="flex items-center space-x-1.5">
                      <Clock className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{course.duration}</span>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5">
                    {course.tags.slice(0, 3).map(tag => (
                      <span key={tag} className="px-2 py-0.5 rounded-md bg-slate-100 text-[10px] text-slate-600 font-medium">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer / Pricing & Action */}
              <div className="p-4 sm:p-5 pt-0 flex flex-col sm:flex-row items-stretch sm:items-center justify-between border-t border-slate-100 mt-2 gap-3">
                <div>
                  <div className="text-[11px] text-slate-500 font-medium">Monthly Tuition</div>
                  <div className="flex items-baseline space-x-1">
                    <span className="text-xl font-black text-slate-900">Rs. {course.price.toLocaleString()}</span>
                    <span className="text-xs text-slate-500 font-semibold">/month</span>
                  </div>
                </div>

                {status === 'enrolled' ? (
                  <button
                    id={`btn-course-enrolled-${course.id}`}
                    onClick={() => onSelectCourse(course)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 hover:bg-emerald-100 font-bold text-xs flex items-center justify-center space-x-1.5 transition-colors cursor-pointer min-h-[44px]"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Go to Classes</span>
                  </button>
                ) : status === 'pending' ? (
                  <button
                    id={`btn-course-pending-${course.id}`}
                    onClick={() => onSelectCourse(course)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-700 font-bold text-xs flex items-center justify-center space-x-1.5 cursor-pointer min-h-[44px]"
                  >
                    <ShieldAlert className="w-4 h-4" />
                    <span>Payment Pending</span>
                  </button>
                ) : status === 'admin' ? (
                  <button
                    id={`btn-course-admin-${course.id}`}
                    onClick={() => onSelectCourse(course)}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition-colors cursor-pointer shadow-xs min-h-[44px] flex items-center justify-center"
                  >
                    Manage Course
                  </button>
                ) : (
                  <button
                    id={`btn-purchase-${course.id}`}
                    onClick={() => {
                      if (!user) {
                        onOpenAuth();
                      } else {
                        onPurchaseCourse(course);
                      }
                    }}
                    className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center space-x-1 cursor-pointer min-h-[44px]"
                  >
                    <span>Purchase Monthly Class</span>
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};

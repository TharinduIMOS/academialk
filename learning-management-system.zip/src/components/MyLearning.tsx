import React, { useState } from 'react';
import { Course, User, ZoomSession, VideoRecording } from '../types';
import { GraduationCap, Video, Play, FileText, CheckCircle2, Calendar, Clock, Download, ExternalLink } from 'lucide-react';

interface MyLearningProps {
  user: User | null;
  courses: Course[];
  onSelectCourse: (course: Course) => void;
  onLaunchZoom: (session: ZoomSession) => void;
  onPlayRecording: (recording: VideoRecording) => void;
  onExploreCourses: () => void;
}

export const MyLearning: React.FC<MyLearningProps> = ({
  user,
  courses,
  onSelectCourse,
  onLaunchZoom,
  onPlayRecording,
  onExploreCourses,
}) => {
  const enrolledCourses = courses.filter(c => user?.enrolledCourseIds.includes(c.id));
  const [selectedCourseId, setSelectedCourseId] = useState<string>(enrolledCourses[0]?.id || '');

  const activeCourse = enrolledCourses.find(c => c.id === selectedCourseId) || enrolledCourses[0];

  if (enrolledCourses.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center max-w-2xl mx-auto space-y-6 my-12 shadow-xs">
        <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto border border-indigo-100">
          <GraduationCap className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold text-slate-900">No Enrolled Courses Yet</h2>
          <p className="text-xs text-slate-500 leading-relaxed">
            Browse our course catalog, enroll in live Zoom classes, and access premium recorded video modules.
          </p>
        </div>
        <button
          id="btn-explore-now"
          onClick={onExploreCourses}
          className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer"
        >
          Explore & Purchase Classes
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white border border-slate-200 p-6 rounded-3xl shadow-xs">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">My Learning Dashboard</h1>
          <p className="text-xs text-slate-500">
            You are enrolled in <strong className="text-indigo-600">{enrolledCourses.length}</strong> active course{enrolledCourses.length > 1 ? 's' : ''}.
          </p>
        </div>

        {/* Course Selector Tabs */}
        <div className="flex items-center space-x-2 overflow-x-auto max-w-full">
          {enrolledCourses.map((course) => (
            <button
              key={course.id}
              id={`tab-mylearning-${course.id}`}
              onClick={() => setSelectedCourseId(course.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                activeCourse?.id === course.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900 border border-slate-200/80 hover:bg-slate-200/60'
              }`}
            >
              {course.title.split(' ')[0]}...
            </button>
          ))}
        </div>
      </div>

      {activeCourse && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Course Workspace */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Active Course Banner */}
            <div className="relative rounded-3xl bg-white border border-slate-200 overflow-hidden shadow-xs">
              <div className="h-44 w-full bg-slate-900 relative">
                <img
                  src={activeCourse.image}
                  alt={activeCourse.title}
                  className="w-full h-full object-cover opacity-75"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent"></div>
              </div>

              <div className="p-6 pt-4 space-y-3">
                <div className="flex items-center space-x-2">
                  <span className="px-2.5 py-1 rounded-md bg-indigo-600 text-white text-[10px] font-extrabold">
                    {activeCourse.category}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">Instructor: {activeCourse.instructor}</span>
                </div>

                <h2 className="text-xl font-bold text-slate-900">{activeCourse.title}</h2>
                <p className="text-xs text-slate-600 leading-relaxed">{activeCourse.description}</p>
              </div>
            </div>

            {/* Video Recordings Section */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center space-x-2">
                  <Play className="w-5 h-5 text-emerald-600" />
                  <h3 className="font-bold text-sm text-slate-900">Course Video Recordings</h3>
                </div>
                <span className="text-xs text-slate-500 font-medium">{activeCourse.recordings.length} Modules Available</span>
              </div>

              {activeCourse.recordings.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400 italic">
                  No video recordings uploaded yet for this course.
                </div>
              ) : (
                <div className="space-y-3">
                  {activeCourse.recordings.map((rec) => (
                    <div
                      key={rec.id}
                      className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 hover:border-slate-300 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                            {rec.chapter}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                            rec.videoUrl.includes('youtu') ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          }`}>
                            {rec.videoUrl.includes('youtu') ? 'YouTube' : 'MP4 Video'}
                          </span>
                        </div>
                        <h4 className="font-bold text-xs sm:text-sm text-slate-900">{rec.title}</h4>
                        <p className="text-xs text-slate-500">{rec.description}</p>
                      </div>

                      <button
                        id={`btn-watch-rec-${rec.id}`}
                        onClick={() => onPlayRecording(rec)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-all flex items-center space-x-1.5 shrink-0 cursor-pointer"
                      >
                        <Play className="w-4 h-4 fill-white" />
                        <span>Watch Video</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* Sidebar - Zoom Live Classes & Course Resources */}
          <div className="space-y-6">
            
            {/* Live Zoom Classes Sidebar Widget */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
              <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
                <Video className="w-5 h-5 text-sky-600" />
                <h3 className="font-bold text-sm text-slate-900">Live Zoom Sessions</h3>
              </div>

              {activeCourse.zoomSessions.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400 italic">
                  No live Zoom classes scheduled right now.
                </div>
              ) : (
                <div className="space-y-3">
                  {activeCourse.zoomSessions.map((session) => (
                    <div
                      key={session.id}
                      className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        {session.status === 'live' ? (
                          <span className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-extrabold animate-pulse">
                            LIVE NOW
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded bg-sky-50 text-sky-700 border border-sky-200 text-[10px] font-semibold">
                            UPCOMING
                          </span>
                        )}
                        <span className="text-[11px] text-slate-500 font-medium">{session.durationMinutes} mins</span>
                      </div>

                      <h4 className="font-bold text-xs text-slate-900">{session.title}</h4>
                      <div className="text-[11px] text-slate-500 flex items-center space-x-1">
                        <Calendar className="w-3.5 h-3.5 text-amber-500" />
                        <span>{new Date(session.scheduledAt).toLocaleString()}</span>
                      </div>

                      <button
                        id={`btn-mylearning-zoom-${session.id}`}
                        onClick={() => onLaunchZoom(session)}
                        className="w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-xs transition-all flex items-center justify-center space-x-1.5 cursor-pointer"
                      >
                        <Video className="w-4 h-4" />
                        <span>Attend Zoom Class</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Resources Widget */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 space-y-4 shadow-xs">
              <div className="flex items-center space-x-2 border-b border-slate-100 pb-3">
                <FileText className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-sm text-slate-900">Course Attachments</h3>
              </div>

              <div className="space-y-2">
                <a
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 hover:border-slate-300 text-xs text-slate-700 font-medium flex items-center justify-between transition-colors"
                >
                  <span className="truncate">Syllabus & Lecture Slides.pdf</span>
                  <Download className="w-4 h-4 text-indigo-600 shrink-0" />
                </a>
                <a
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 hover:border-slate-300 text-xs text-slate-700 font-medium flex items-center justify-between transition-colors"
                >
                  <span className="truncate">Source Code Examples.zip</span>
                  <Download className="w-4 h-4 text-indigo-600 shrink-0" />
                </a>
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};

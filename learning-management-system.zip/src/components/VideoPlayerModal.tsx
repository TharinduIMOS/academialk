import React, { useState } from 'react';
import { VideoRecording } from '../types';
import { X, Play, FileText, Download, MessageSquare, CheckCircle2 } from 'lucide-react';

interface VideoPlayerModalProps {
  recording: VideoRecording | null;
  onClose: () => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({ recording, onClose }) => {
  const [activeTab, setActiveTab] = useState<'resources' | 'notes'>('resources');
  const [notes, setNotes] = useState('');
  const [savedNotes, setSavedNotes] = useState<string[]>([]);

  if (!recording) return null;

  const getYouTubeEmbedUrl = (url: string): string | null => {
    if (!url) return null;
    const trimmed = url.trim();
    if (trimmed.includes('youtube.com/embed/')) {
      const id = trimmed.split('youtube.com/embed/')[1]?.split('?')[0]?.split('&')[0];
      if (id) return `https://www.youtube.com/embed/${id}?autoplay=1&rel=0`;
    }
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = trimmed.match(regExp);
    if (match && match[2] && match[2].length === 11) {
      return `https://www.youtube.com/embed/${match[2]}?autoplay=1&rel=0`;
    }
    return null;
  };

  const youtubeEmbedUrl = getYouTubeEmbedUrl(recording.videoUrl);

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notes.trim()) return;
    setSavedNotes([notes.trim(), ...savedNotes]);
    setNotes('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white border border-slate-200 rounded-3xl shadow-xl overflow-hidden text-slate-800 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center space-x-2">
            <Play className="w-5 h-5 text-emerald-600 fill-emerald-600" />
            <span className="font-bold text-slate-900 text-sm">Lecture Video Recording Player</span>
          </div>
          <button
            id="btn-close-video-modal"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Custom Video Player Embed (YouTube or HTML5 MP4) */}
        <div className="relative aspect-video w-full bg-black">
          {youtubeEmbedUrl ? (
            <iframe
              id="youtube-player-element"
              src={youtubeEmbedUrl}
              title={recording.title}
              className="w-full h-full border-0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
            />
          ) : (
            <video
              id="video-player-element"
              controls
              autoPlay
              controlsList="nodownload"
              poster="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=1200&auto=format&fit=crop&q=80"
              src={recording.videoUrl}
              className="w-full h-full object-contain"
            >
              Your browser does not support HTML5 video playback.
            </video>
          )}
        </div>

        {/* Video Info Header */}
        <div className="p-6 bg-slate-50/80 border-b border-slate-200 space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-[11px] font-bold text-indigo-700 uppercase tracking-wider">
              {recording.chapter} • Duration: {recording.duration}
            </div>
            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
              youtubeEmbedUrl ? 'bg-red-100 text-red-700 border border-red-200' : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
            }`}>
              {youtubeEmbedUrl ? 'YouTube Stream' : 'MP4 Direct Video'}
            </span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900">{recording.title}</h2>
          <p className="text-xs text-slate-600 leading-relaxed">{recording.description}</p>
        </div>

        {/* Bottom Tabbed Section (Resources & Personal Notes) */}
        <div className="p-6 space-y-4 bg-white">
          <div className="flex space-x-4 border-b border-slate-200 pb-2">
            <button
              id="vtab-resources"
              onClick={() => setActiveTab('resources')}
              className={`text-xs font-bold pb-2 border-b-2 flex items-center space-x-1.5 transition-colors cursor-pointer ${
                activeTab === 'resources'
                  ? 'border-indigo-600 text-indigo-700'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Lesson Files & Slides ({recording.resources?.length || 0})</span>
            </button>
            <button
              id="vtab-notes"
              onClick={() => setActiveTab('notes')}
              className={`text-xs font-bold pb-2 border-b-2 flex items-center space-x-1.5 transition-colors cursor-pointer ${
                activeTab === 'notes'
                  ? 'border-indigo-600 text-indigo-700'
                  : 'border-transparent text-slate-500 hover:text-slate-900'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>Personal Notes ({savedNotes.length})</span>
            </button>
          </div>

          {activeTab === 'resources' && (
            <div className="space-y-2">
              {!recording.resources || recording.resources.length === 0 ? (
                <div className="text-xs text-slate-500 italic py-2">
                  No attachments associated with this video.
                </div>
              ) : (
                recording.resources.map((res) => (
                  <div
                    key={res.id}
                    className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs text-slate-800"
                  >
                    <span className="font-semibold">{res.title}</span>
                    <a
                      href={res.fileUrl || '#'}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 hover:bg-indigo-100 text-[11px] font-bold flex items-center space-x-1 transition-colors cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download File</span>
                    </a>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'notes' && (
            <div className="space-y-3">
              <form onSubmit={handleSaveNote} className="flex gap-2">
                <input
                  id="input-lecture-note"
                  type="text"
                  placeholder="Take a quick note at current timestamp..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600"
                />
                <button
                  id="btn-save-note"
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shadow-xs"
                >
                  Add Note
                </button>
              </form>

              <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                {savedNotes.map((note, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 flex items-start space-x-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                    <span className="font-medium">{note}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Modal Footer with Close Button */}
          <div className="pt-4 border-t border-slate-200 flex justify-end">
            <button
              id="btn-close-video-modal-footer"
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Close Video Player
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};

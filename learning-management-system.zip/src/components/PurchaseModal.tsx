import React, { useState } from 'react';
import { Course, User, PaymentTransaction } from '../types';
import { X, CreditCard, Landmark, CheckCircle2, ShieldCheck, Upload, AlertCircle, ArrowRight, FileCheck } from 'lucide-react';

interface PurchaseModalProps {
  course: Course | null;
  user: User | null;
  initialMonth?: string;
  onClose: () => void;
  onSuccess: (payment: PaymentTransaction, updatedUser: User) => void;
}

export const PurchaseModal: React.FC<PurchaseModalProps> = ({
  course,
  user,
  initialMonth,
  onClose,
  onSuccess,
}) => {
  const [selectedMonth, setSelectedMonth] = useState<string>(
    initialMonth || course?.availableMonths?.[0] || 'July 2026'
  );
  // Default to bank_transfer only as requested
  const [paymentMethod, setPaymentMethod] = useState<'bank_transfer' | 'card'>('bank_transfer');
  
  // Bank transfer fields
  const [referenceCode, setReferenceCode] = useState(`TXN-BANK-${Math.floor(100000 + Math.random() * 900000)}`);
  const [receiptUrl, setReceiptUrl] = useState<string>('');
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [note, setNote] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // File Upload Handler for Receipt Image with Canvas Downscaling
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file (PNG, JPG, WEBP).');
        return;
      }
      setUploadedFileName(file.name);
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const maxDim = 1200;
          let width = img.width;
          let height = img.height;
          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
            setReceiptUrl(dataUrl);
            setError(null);
          } else {
            setReceiptUrl(event.target?.result as string);
            setError(null);
          }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  if (!course || !user) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!receiptUrl && paymentMethod === 'bank_transfer') {
      setError('Receipt image proof is required. Please upload an image or select a sample receipt.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const payload = {
        userId: user.id,
        courseId: course.id,
        month: selectedMonth,
        paymentMethod: 'bank_transfer',
        receiptUrl: receiptUrl,
        referenceCode: referenceCode,
        note: note || `Bank Transfer Receipt Proof Submitted for ${selectedMonth}`,
      };

      const res = await fetch('/api/payments/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (res.ok && data.payment) {
        onSuccess(data.payment, data.user || user);
        onClose();
      } else {
        setError(data.error || 'Payment submission failed');
      }
    } catch (err) {
      setError('Connection error submitting payment');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white border border-slate-200 rounded-3xl shadow-xl overflow-hidden text-slate-800 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5 text-indigo-600" />
            <span className="font-bold text-slate-900 text-sm">Monthly Checkout & Access Authorization</span>
          </div>
          <button
            id="btn-close-purchase-modal"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Course Summary Box */}
        <div className="p-6 bg-slate-50/70 border-b border-slate-200 space-y-4">
          <div className="flex items-center space-x-3">
            <img
              src={course.image}
              alt={course.title}
              className="w-14 h-14 rounded-xl object-cover border border-slate-200 shadow-xs"
            />
            <div>
              <div className="text-xs text-indigo-600 font-bold">{course.category}</div>
              <h3 className="font-bold text-sm text-slate-900 leading-tight">{course.title}</h3>
              <div className="text-xs text-slate-500">Teacher: {course.instructor}</div>
            </div>
          </div>

          {/* Month Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Select Subscription Month:
            </label>
            <select
              id="select-purchase-month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:border-indigo-600 cursor-pointer shadow-xs"
            >
              {(course.availableMonths || ['July 2026', 'August 2026', 'September 2026', 'October 2026', 'November 2026', 'December 2026']).map((m) => (
                <option key={m} value={m}>
                  {m} Access Package — Rs. {course.price.toLocaleString()}.00/mo
                </option>
              ))}
            </select>
          </div>
          
          <div className="flex items-center justify-between p-3 rounded-xl bg-white border border-slate-200 text-xs shadow-xs">
            <div>
              <span className="text-slate-500 font-semibold block">Monthly Tuition ({selectedMonth}):</span>
              <span className="text-[11px] text-emerald-600 font-medium">Includes Live Zoom + All Video Recordings</span>
            </div>
            <span className="text-xl font-black text-slate-900">Rs. {course.price.toLocaleString()}</span>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
              {error}
            </div>
          )}

          {/* Payment Method Selector */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-bold text-slate-700">
                Payment Method
              </label>
              <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-bold">
                Bank Wire Only Enabled
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              {/* Bank Wire Button (Active) */}
              <button
                id="pm-bank"
                type="button"
                onClick={() => setPaymentMethod('bank_transfer')}
                className="p-3 rounded-xl border-2 text-left transition-all flex items-center space-x-2.5 cursor-pointer border-amber-600 bg-amber-50/90 text-amber-950 font-bold shadow-sm"
              >
                <Landmark className="w-5 h-5 text-amber-600 shrink-0" />
                <div>
                  <div className="text-xs font-bold">Bank Wire Transfer</div>
                  <div className="text-[10px] text-amber-700 font-semibold">Requires Receipt Slip Upload</div>
                </div>
              </button>

              {/* Card Button (Disabled) */}
              <button
                id="pm-card-disabled"
                type="button"
                disabled
                className="p-3 rounded-xl border border-slate-200 text-left bg-slate-100 text-slate-400 opacity-70 cursor-not-allowed flex items-center space-x-2.5 relative overflow-hidden"
              >
                <CreditCard className="w-5 h-5 text-slate-400 shrink-0" />
                <div>
                  <div className="text-xs font-bold line-through">Credit / Debit Card</div>
                  <div className="text-[10px] text-rose-600 font-bold">Disabled for now</div>
                </div>
              </button>
            </div>
          </div>

          {/* Bank Wire Transfer Details & Receipt Proof Image Upload */}
          <div className="space-y-4 p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs space-y-1">
              <div className="flex items-center space-x-1.5 font-bold text-amber-900">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Bank Wire Instructions & Manual Approval</span>
              </div>
              <p className="text-[11px] text-amber-800 leading-relaxed pl-5">
                Deposit <strong>Rs. {course.price.toLocaleString()}</strong> to <strong>Commercial Bank / BOC A/C #9948-2019-33</strong>. Upload your transaction receipt slip below for admin approval.
              </p>
            </div>

            {/* Reference Code Input */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Bank Reference / Transfer Code <span className="text-rose-500">*</span>
              </label>
              <input
                id="input-bank-ref"
                type="text"
                required
                value={referenceCode}
                onChange={(e) => setReferenceCode(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-amber-600 font-mono font-bold shadow-xs"
              />
            </div>

            {/* REAL RECEIPT IMAGE FILE UPLOADER */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-slate-700">
                  Receipt Image Proof <span className="text-rose-500">*</span>
                </label>
                <span className="text-[10px] text-slate-500">Supports PNG, JPG, WEBP</span>
              </div>

              {/* File Input */}
              <input
                id="input-receipt-file-upload"
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />

              {/* Upload Dropzone / Button */}
              <div
                onClick={() => document.getElementById('input-receipt-file-upload')?.click()}
                className="border-2 border-dashed border-indigo-200 hover:border-indigo-500 bg-indigo-50/40 hover:bg-indigo-50 p-4 rounded-2xl text-center cursor-pointer transition-all space-y-2"
              >
                <div className="w-10 h-10 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-indigo-900">Click to Upload Receipt Image Proof</div>
                  <div className="text-[10px] text-slate-500">or browse image files from your computer</div>
                </div>
              </div>

              {/* Live Uploaded Image Preview Box */}
              {receiptUrl && (
                <div className="p-3 bg-white border border-slate-200 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                    <span className="flex items-center space-x-1.5 truncate">
                      <FileCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="truncate">{uploadedFileName || 'Uploaded_Receipt_Proof.jpg'}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setReceiptUrl('');
                        setUploadedFileName(null);
                      }}
                      className="text-[11px] text-rose-600 hover:underline font-bold shrink-0 ml-2"
                    >
                      Remove
                    </button>
                  </div>
                  <div className="relative rounded-xl overflow-hidden border border-slate-200 max-h-48 bg-slate-900 flex items-center justify-center">
                    <img
                      src={receiptUrl}
                      alt="Receipt Proof Preview"
                      className="max-h-44 w-auto object-contain"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Note Input */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Student Wire Note (Optional)</label>
              <input
                id="input-payment-note"
                type="text"
                placeholder="e.g. Sent via Mobile Banking App Ref #9920"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          <div className="pt-2 flex items-center space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer min-h-[44px]"
            >
              Cancel
            </button>
            <button
              id="btn-confirm-purchase"
              type="submit"
              disabled={loading}
              className="flex-1 py-3.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs transition-all shadow-md flex items-center justify-center space-x-2 cursor-pointer min-h-[44px]"
            >
              {loading ? (
                <span>Submitting Receipt Proof...</span>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>Submit Receipt Proof for Approval (Rs. {course.price.toLocaleString()}/mo)</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

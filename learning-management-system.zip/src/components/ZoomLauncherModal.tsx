import React, { useState } from 'react';
import { ZoomSession } from '../types';
import { X, Video, Copy, Check, ExternalLink, ShieldCheck, Clock, User as UserIcon } from 'lucide-react';

interface ZoomLauncherModalProps {
  session: ZoomSession | null;
  onClose: () => void;
}

export const ZoomLauncherModal: React.FC<ZoomLauncherModalProps> = ({ session, onClose }) => {
  const [copiedId, setCopiedId] = useState(false);
  const [copiedPasscode, setCopiedPasscode] = useState(false);

  if (!session) return null;

  const copyToClipboard = (text: string, type: 'id' | 'passcode') => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } else {
      setCopiedPasscode(true);
      setTimeout(() => setCopiedPasscode(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="relative w-full max-w-md bg-white border border-slate-200 rounded-3xl shadow-xl overflow-hidden text-slate-800">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700">
              <Video className="w-4 h-4" />
            </div>
            <span className="font-bold text-slate-900 text-sm">Zoom Class Launcher</span>
          </div>
          <button
            id="btn-close-zoom-modal"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-5">
          
          {/* Status Badge & Title */}
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              {session.status === 'live' ? (
                <span className="px-2.5 py-1 rounded bg-rose-600 text-white text-[10px] font-extrabold animate-pulse">
                  ● LIVE CLASS IN PROGRESS
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded bg-sky-50 text-sky-700 text-[10px] font-bold border border-sky-200">
                  SCHEDULED ZOOM SESSION
                </span>
              )}
              <span className="text-xs text-slate-500 font-medium">{session.durationMinutes} mins</span>
            </div>

            <h3 className="text-lg font-bold text-slate-900 leading-snug">{session.title}</h3>
            
            <div className="text-xs text-slate-500 flex items-center space-x-2 pt-1 font-medium">
              <UserIcon className="w-3.5 h-3.5 text-indigo-600" />
              <span>Host: <strong className="text-slate-900 font-bold">{session.hostName || 'Faculty Lead'}</strong></span>
            </div>
          </div>

          {/* Direct Launch Button */}
          <a
            id="btn-launch-zoom-direct"
            href={session.zoomUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-extrabold text-xs shadow-xs transition-all flex items-center justify-center space-x-2 cursor-pointer"
          >
            <Video className="w-4.5 h-4.5" />
            <span>Open & Join Zoom Meeting</span>
            <ExternalLink className="w-4 h-4" />
          </a>

          {/* Meeting Credentials Cards */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Meeting Credentials
            </div>

            {/* Meeting ID */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs">
              <div>
                <div className="text-[10px] text-slate-400 font-medium">Meeting ID</div>
                <div className="text-xs font-mono font-bold text-slate-900">{session.meetingId}</div>
              </div>
              <button
                id="btn-copy-meeting-id"
                onClick={() => copyToClipboard(session.meetingId, 'id')}
                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center space-x-1 transition-colors cursor-pointer"
              >
                {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            {/* Passcode */}
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-white border border-slate-200 shadow-xs">
              <div>
                <div className="text-[10px] text-slate-400 font-medium">Passcode</div>
                <div className="text-xs font-mono font-bold text-indigo-700">{session.passcode}</div>
              </div>
              <button
                id="btn-copy-passcode"
                onClick={() => copyToClipboard(session.passcode, 'passcode')}
                className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center space-x-1 transition-colors cursor-pointer"
              >
                {copiedPasscode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedPasscode ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

          </div>

          <div className="pt-1 flex items-center space-x-2">
            <button
              id="btn-close-zoom-modal-bottom"
              type="button"
              onClick={onClose}
              className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Close Window
            </button>
          </div>

          <div className="text-[11px] text-slate-500 flex items-center space-x-1 justify-center font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Secured Zoom Link authenticated by Academia LMS</span>
          </div>

        </div>

      </div>
    </div>
  );
};

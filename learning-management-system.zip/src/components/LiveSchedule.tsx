import React from 'react';
import { Course, User, ZoomSession } from '../types';
import { Calendar, Video, Clock, CheckCircle2, Lock, Sparkles, User as UserIcon } from 'lucide-react';

interface LiveScheduleProps {
  courses: Course[];
  user: User | null;
  onLaunchZoom: (session: ZoomSession) => void;
  onOpenAuth: () => void;
  onExploreCourses: () => void;
}

export const LiveSchedule: React.FC<LiveScheduleProps> = ({
  courses,
  user,
  onLaunchZoom,
  onOpenAuth,
  onExploreCourses,
}) => {
  // Aggregate all Zoom sessions
  const allZoomSessions = courses.flatMap(c =>
    c.zoomSessions.map(s => ({
      ...s,
      courseTitle: c.title,
      courseCategory: c.category,
      isEnrolled: user?.enrolledCourseIds.includes(c.id) || user?.role === 'admin',
    }))
  );

  // Sort by date / live first
  const sortedSessions = [...allZoomSessions].sort((a, b) => {
    if (a.status === 'live') return -1;
    if (b.status === 'live') return 1;
    return new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime();
  });

  return (
    <div className="space-y-8 pb-12">
      
      {/* Header */}
      <div className="bg-white border border-slate-200 p-8 rounded-3xl space-y-3 shadow-xs">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-700 text-xs font-semibold">
          <Calendar className="w-3.5 h-3.5 text-amber-600" />
          <span>Zoom Live Cohort Timetable</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Live Zoom Class Schedule</h1>
        <p className="text-xs sm:text-sm text-slate-500 max-w-2xl leading-relaxed">
          Join real-time lecture streams, interactive workshops, and live code reviews directly through authenticated Zoom links.
        </p>
      </div>

      {/* Sessions Agenda List */}
      {sortedSessions.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center space-y-4 shadow-xs">
          <Video className="w-12 h-12 text-slate-400 mx-auto" />
          <div className="text-sm text-slate-500 font-medium">No scheduled Zoom sessions available currently.</div>
        </div>
      ) : (
        <div className="space-y-4">
          {sortedSessions.map((session) => (
            <div
              key={session.id}
              className={`p-6 rounded-3xl border transition-all ${
                session.status === 'live'
                  ? 'bg-white border-rose-300 shadow-md shadow-rose-50'
                  : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
              }`}
            >
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                
                <div className="space-y-2 flex-1">
                  <div className="flex items-center space-x-2">
                    {session.status === 'live' ? (
                      <span className="px-3 py-1 rounded-md bg-rose-600 text-white text-xs font-black animate-pulse flex items-center space-x-1 shadow-xs">
                        <span className="w-2 h-2 rounded-full bg-white"></span>
                        <span>LIVE NOW</span>
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-md bg-sky-50 text-sky-700 border border-sky-200 text-xs font-semibold">
                        UPCOMING
                      </span>
                    )}

                    <span className="px-2.5 py-1 rounded-md bg-slate-100 text-slate-700 text-xs font-medium border border-slate-200/60">
                      {session.courseCategory}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900">{session.title}</h3>

                  <div className="text-xs text-indigo-600 font-semibold">
                    Course: {session.courseTitle}
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 pt-1 font-medium">
                    <span className="flex items-center space-x-1">
                      <Calendar className="w-3.5 h-3.5 text-amber-600" />
                      <span>{new Date(session.scheduledAt).toLocaleString()}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{session.durationMinutes} Minutes</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <UserIcon className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Host: {session.hostName || 'Instructor'}</span>
                    </span>
                  </div>
                </div>

                {/* Right Action */}
                <div className="shrink-0 w-full md:w-auto">
                  {session.isEnrolled ? (
                    <button
                      id={`btn-schedule-join-${session.id}`}
                      onClick={() => onLaunchZoom(session)}
                      className="w-full md:w-auto px-6 py-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-xs transition-all flex items-center justify-center space-x-2 cursor-pointer min-h-[44px]"
                    >
                      <Video className="w-4 h-4" />
                      <span>Launch Zoom Class</span>
                    </button>
                  ) : user ? (
                    <button
                      id={`btn-schedule-enroll-${session.id}`}
                      onClick={onExploreCourses}
                      className="w-full md:w-auto px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-bold transition-colors flex items-center justify-center space-x-1.5 cursor-pointer min-h-[44px]"
                    >
                      <Lock className="w-3.5 h-3.5 text-amber-600" />
                      <span>Enroll in Course to Attend</span>
                    </button>
                  ) : (
                    <button
                      id={`btn-schedule-login-${session.id}`}
                      onClick={onOpenAuth}
                      className="w-full md:w-auto px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer min-h-[44px] flex items-center justify-center"
                    >
                      Login to Attend
                    </button>
                  )}
                </div>

              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
};

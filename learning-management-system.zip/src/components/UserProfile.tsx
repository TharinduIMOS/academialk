import React, { useState } from 'react';
import { User, PaymentTransaction } from '../types';
import { User as UserIcon, Mail, Phone, FileText, CreditCard, CheckCircle2, ShieldAlert, Clock, Save, ShieldCheck, Upload, Camera } from 'lucide-react';

interface UserProfileProps {
  user: User;
  payments: PaymentTransaction[];
  onUpdateProfile: (updatedUser: User) => void;
  onExploreCourses: () => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({
  user,
  payments,
  onUpdateProfile,
  onExploreCourses,
}) => {
  const [name, setName] = useState(user.name);
  const [avatar, setAvatar] = useState(user.avatar || '');
  const [phone, setPhone] = useState(user.phone || '');
  const [bio, setBio] = useState(user.bio || '');

  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const userPayments = payments.filter(p => p.userId === user.id);

  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setMessage('Image size should be under 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatar(reader.result as string);
        setMessage('Profile photo loaded! Click Save to apply.');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage(null);

    try {
      const res = await fetch('/api/users/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          name,
          avatar,
          phone,
          bio,
        }),
      });

      const data = await res.json();
      if (res.ok && data.user) {
        onUpdateProfile(data.user);
        setMessage('Profile updated successfully!');
        setTimeout(() => setMessage(null), 3000);
      } else {
        setMessage(data.error || 'Failed to update profile');
      }
    } catch (err) {
      setMessage('Error updating profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8 pb-12 max-w-5xl mx-auto">
      
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 p-8 rounded-3xl flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6 shadow-xs">
        <img
          src={avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
          alt={user.name}
          className="w-20 h-20 rounded-2xl object-cover border-2 border-indigo-200 shadow-sm"
        />
        <div className="text-center sm:text-left space-y-1">
          <div className="flex items-center justify-center sm:justify-start space-x-2">
            <h1 className="text-2xl font-bold text-slate-900">{user.name}</h1>
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold capitalize border border-indigo-200/60">
              {user.role}
            </span>
          </div>
          <p className="text-xs text-slate-500">{user.email}</p>
          <div className="text-[11px] text-slate-400 font-medium">
            Account Created: {new Date(user.createdAt).toLocaleDateString()}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Profile Edit Form */}
        <div className="lg:col-span-1 bg-white border border-slate-200 rounded-3xl p-6 space-y-5 shadow-xs">
          <h2 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
            Account Details & Profile
          </h2>

          {message && (
            <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-medium">
              {message}
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                id="input-profile-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-indigo-600 focus:bg-white transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Teacher / Profile Photo</label>
              <div className="flex items-center space-x-3 mb-2">
                <img
                  src={avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
                  alt="Avatar Preview"
                  className="w-12 h-12 rounded-xl object-cover border border-slate-200 shrink-0"
                />
                <label className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold flex items-center space-x-1.5 border border-indigo-200 cursor-pointer transition-all">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Local Photo</span>
                  <input
                    id="input-file-profile-avatar"
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
              <input
                id="input-profile-avatar"
                type="text"
                value={avatar}
                placeholder="Or paste image URL (https://...)"
                onChange={(e) => setAvatar(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-indigo-600 focus:bg-white transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
              <input
                id="input-profile-phone"
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-indigo-600 focus:bg-white transition-all"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Bio / Study Focus</label>
              <textarea
                id="input-profile-bio"
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:border-indigo-600 focus:bg-white transition-all"
              />
            </div>

            <button
              id="btn-save-user-profile"
              type="submit"
              disabled={saving}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-1.5 shadow-xs cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving...' : 'Save Profile Changes'}</span>
            </button>
          </form>
        </div>

        {/* Purchase & Payment Approval Status History */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-3xl p-6 space-y-5 shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <h2 className="text-base font-bold text-slate-900 flex items-center space-x-2">
              <CreditCard className="w-4 h-4 text-indigo-600" />
              <span>Course Purchases & Payment Status</span>
            </h2>
            <button
              id="btn-profile-explore"
              onClick={onExploreCourses}
              className="text-xs text-indigo-600 hover:text-indigo-700 font-bold cursor-pointer"
            >
              + Purchase Another Class
            </button>
          </div>

          {userPayments.length === 0 ? (
            <div className="text-center py-10 text-xs text-slate-500 space-y-2">
              <div>No purchase transaction records found.</div>
              <button
                onClick={onExploreCourses}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold cursor-pointer shadow-xs"
              >
                Browse Catalog
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {userPayments.map((pay) => (
                <div
                  key={pay.id}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{pay.courseTitle}</h4>
                      <div className="text-xs text-slate-500 flex items-center space-x-2 pt-0.5">
                        <span>Ref: <code className="text-indigo-600 font-mono font-bold">{pay.referenceCode}</code></span>
                        <span>• Method: <span className="capitalize">{pay.paymentMethod.replace('_', ' ')}</span></span>
                      </div>
                    </div>

                    {pay.status === 'approved' ? (
                      <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-bold border border-emerald-200 flex items-center space-x-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Payment Approved</span>
                      </span>
                    ) : pay.status === 'pending' ? (
                      <span className="px-3 py-1 rounded-full bg-amber-50 text-amber-700 text-xs font-bold border border-amber-200 flex items-center space-x-1 animate-pulse">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Pending Admin Approval</span>
                      </span>
                    ) : (
                      <span className="px-3 py-1 rounded-full bg-rose-50 text-rose-700 text-xs font-bold border border-rose-200 flex items-center space-x-1">
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>Payment Rejected</span>
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-xs text-slate-500 border-t border-slate-200/60 pt-2">
                    <span>Submitted: {new Date(pay.createdAt).toLocaleString()}</span>
                    <span className="font-black text-slate-900 text-sm">${pay.amount}.00</span>
                  </div>

                  {pay.status === 'pending' && (
                    <div className="text-[11px] text-amber-800 bg-amber-50 p-2.5 rounded-xl border border-amber-200/80 leading-relaxed font-medium">
                      Your bank transfer receipt is currently queued in the Admin Payment Approvals dashboard. Once verified, access to live Zoom links and video recordings will be unlocked automatically.
                    </div>
                  )}

                  {pay.rejectionReason && (
                    <div className="text-[11px] text-rose-800 bg-rose-50 p-2.5 rounded-xl border border-rose-200/80 leading-relaxed font-medium">
                      Reason for Rejection: {pay.rejectionReason}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};

import React, { useState } from 'react';
import { Course, User, PaymentTransaction, ZoomSession, VideoRecording } from '../types';
import { X, Video, Play, FileText, CheckCircle2, ShieldAlert, Calendar, Clock, Star, Lock, User as UserIcon, ExternalLink } from 'lucide-react';

interface CourseDetailModalProps {
  course: Course | null;
  user: User | null;
  payments: PaymentTransaction[];
  onClose: () => void;
  onPurchase: (course: Course) => void;
  onLaunchZoom: (session: ZoomSession) => void;
  onPlayRecording: (recording: VideoRecording) => void;
}

export const CourseDetailModal: React.FC<CourseDetailModalProps> = ({
  course,
  user,
  payments,
  onClose,
  onPurchase,
  onLaunchZoom,
  onPlayRecording,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'zoom' | 'recordings'>('overview');
  const [selectedMonth, setSelectedMonth] = useState<string>(
    course?.availableMonths?.[0] || 'July 2026'
  );

  if (!course) return null;

  const monthsList = course.availableMonths || ['July 2026', 'August 2026', 'September 2026', 'October 2026', 'November 2026', 'December 2026'];
  const currentMonthKey = `${course.id}_${selectedMonth}`;
  
  const isEnrolledInSelectedMonth =
    user?.role === 'admin' ||
    user?.enrolledMonthKeys?.includes(currentMonthKey);

  const pendingPaymentForMonth = payments.find(
    (p) => p.userId === user?.id && p.courseId === course.id && p.month === selectedMonth && p.status === 'pending'
  );

  // Filter Zoom sessions & Recordings for selected month
  const monthZoomSessions = course.zoomSessions.filter(
    (s) => !s.month || s.month === selectedMonth
  );

  const monthRecordings = course.recordings.filter(
    (r) => !r.month || r.month === selectedMonth
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white border border-slate-200 rounded-3xl shadow-xl overflow-hidden text-slate-800 my-8">
        
        {/* Banner Image */}
        <div className="relative h-60 sm:h-72 w-full bg-slate-100">
          <img
            src={course.image}
            alt={course.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/50 to-transparent"></div>
          
          <button
            id="btn-close-course-modal"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-slate-900/70 text-slate-200 hover:text-white hover:bg-slate-900 transition-colors z-10 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-6 left-6 right-6 space-y-2">
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 rounded-md bg-indigo-600 text-white text-xs font-bold shadow-xs">
                {course.category}
              </span>
              <span className="px-3 py-1 rounded-md bg-slate-900/80 text-slate-200 text-xs font-medium border border-slate-700/80">
                {course.level}
              </span>
              <span className="px-3 py-1 rounded-md bg-emerald-600 text-white text-xs font-bold">
                Rs. {course.price.toLocaleString()}/month
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-snug">
              {course.title}
            </h2>
            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-200">
              <span className="flex items-center space-x-1 text-amber-400 font-bold">
                <Star className="w-4 h-4 fill-amber-400" />
                <span>{course.rating}</span>
                <span className="text-slate-300 font-normal">({course.reviewsCount} student reviews)</span>
              </span>
              <span className="flex items-center space-x-1">
                <Clock className="w-4 h-4 text-emerald-400" />
                <span>Teacher: {course.instructor}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Month Selector Bar */}
        <div className="bg-slate-900 px-6 py-3 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center space-x-2 text-xs text-slate-300 font-bold shrink-0">
            <Calendar className="w-4 h-4 text-indigo-400" />
            <span>Select Month:</span>
          </div>
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {monthsList.map((m) => {
              const mKey = `${course.id}_${m}`;
              const isPaid = user?.role === 'admin' || user?.enrolledMonthKeys?.includes(mKey);
              const isSelected = selectedMonth === m;

              return (
                <button
                  key={m}
                  onClick={() => setSelectedMonth(m)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center space-x-1.5 ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  <span>{m}</span>
                  {isPaid ? (
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  ) : (
                    <Lock className="w-3 h-3 text-slate-400" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Modal Navigation Bar */}
        <div className="flex border-b border-slate-200 px-6 bg-slate-50">
          <button
            id="modal-tab-overview"
            onClick={() => setActiveTab('overview')}
            className={`py-3.5 px-4 font-bold text-xs transition-colors border-b-2 cursor-pointer ${
              activeTab === 'overview'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Course & Teacher Profile
          </button>
          <button
            id="modal-tab-zoom"
            onClick={() => setActiveTab('zoom')}
            className={`py-3.5 px-4 font-bold text-xs transition-colors border-b-2 flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'zoom'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Video className="w-4 h-4 text-sky-600" />
            <span>{selectedMonth} Zoom Classes ({monthZoomSessions.length})</span>
          </button>
          <button
            id="modal-tab-recordings"
            onClick={() => setActiveTab('recordings')}
            className={`py-3.5 px-4 font-bold text-xs transition-colors border-b-2 flex items-center space-x-1.5 cursor-pointer ${
              activeTab === 'recordings'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Play className="w-4 h-4 text-emerald-600" />
            <span>{selectedMonth} Recordings ({monthRecordings.length})</span>
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-6">
          
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-bold text-slate-900 mb-2">About This Course</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{course.description}</p>
              </div>

              {/* Dedicated Teacher Display Card */}
              <div className="p-5 rounded-2xl bg-indigo-50/70 border border-indigo-200/90 space-y-3">
                <div className="flex items-center space-x-2 text-indigo-900 font-bold text-xs">
                  <UserIcon className="w-4 h-4 text-indigo-600" />
                  <span>Course Instructor Details</span>
                </div>
                <div className="flex items-start space-x-4">
                  <img
                    src={course.instructorAvatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80'}
                    alt={course.instructor}
                    className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-300 shadow-xs"
                  />
                  <div className="space-y-1">
                    <div className="text-base font-extrabold text-slate-900">{course.instructor}</div>
                    <div className="text-xs text-indigo-700 font-semibold">{course.instructorTitle || 'Senior Subject Master & Lecturer'}</div>
                    <p className="text-xs text-slate-600 leading-relaxed pt-1">
                      {course.instructorBio || 'Distinguished academic instructor with extensive experience preparing students for Advanced Level success.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Weekly Schedule */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="text-xs font-bold text-slate-900 flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-amber-600" />
                  <span>Weekly Live Schedule & Timing</span>
                </div>
                <div className="text-xs text-slate-600 pl-6">{course.scheduleText}</div>
              </div>
            </div>
          )}

          {activeTab === 'zoom' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Zoom Sessions for <strong>{selectedMonth}</strong></span>
                <span className="text-indigo-600 font-bold">{selectedMonth}</span>
              </div>

              {!isEnrolledInSelectedMonth ? (
                <div className="p-6 rounded-3xl bg-amber-50 border border-amber-200 text-center space-y-3">
                  <Lock className="w-8 h-8 text-amber-600 mx-auto" />
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm">Access Restricted for {selectedMonth}</h4>
                    <p className="text-xs text-slate-600 max-w-md mx-auto mt-1">
                      You do not have an active subscription for <strong>{selectedMonth}</strong> of {course.title}. Please purchase {selectedMonth} monthly access to join live Zoom classes.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      onClose();
                      onPurchase(course);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer inline-block"
                  >
                    Purchase {selectedMonth} Access (Rs. {course.price.toLocaleString()}/mo)
                  </button>
                </div>
              ) : monthZoomSessions.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-500">
                  No Zoom classes scheduled yet for {selectedMonth}.
                </div>
              ) : (
                monthZoomSessions.map((session) => (
                  <div
                    key={session.id}
                    className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        {session.status === 'live' ? (
                          <span className="px-2 py-0.5 rounded bg-rose-600 text-white text-[10px] font-extrabold animate-pulse">
                            LIVE NOW
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded bg-sky-100 text-sky-700 text-[10px] font-bold border border-sky-200">
                            UPCOMING
                          </span>
                        )}
                        <span className="text-xs text-slate-500 font-medium">
                          {new Date(session.scheduledAt).toLocaleString()} ({session.durationMinutes} mins)
                        </span>
                      </div>
                      <h4 className="font-bold text-sm text-slate-900">{session.title}</h4>
                      <div className="text-xs text-slate-500">Host: {session.hostName || course.instructor}</div>
                    </div>

                    <button
                      id={`btn-join-zoom-${session.id}`}
                      onClick={() => onLaunchZoom(session)}
                      className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-xs transition-all flex items-center space-x-1.5 shrink-0 cursor-pointer"
                    >
                      <Video className="w-4 h-4" />
                      <span>Join Zoom Class</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'recordings' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Lecture Video Recordings for <strong>{selectedMonth}</strong></span>
                <span className="text-indigo-600 font-bold">{selectedMonth}</span>
              </div>

              {!isEnrolledInSelectedMonth ? (
                <div className="p-6 rounded-3xl bg-amber-50 border border-amber-200 text-center space-y-3">
                  <Lock className="w-8 h-8 text-amber-600 mx-auto" />
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm">Access Restricted for {selectedMonth}</h4>
                    <p className="text-xs text-slate-600 max-w-md mx-auto mt-1">
                      You do not have an active subscription for <strong>{selectedMonth}</strong> of {course.title}. Purchase {selectedMonth} access to watch recorded lectures and download resources.
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      onClose();
                      onPurchase(course);
                    }}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer inline-block"
                  >
                    Purchase {selectedMonth} Access (Rs. {course.price.toLocaleString()}/mo)
                  </button>
                </div>
              ) : monthRecordings.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-500">
                  No video recordings uploaded yet for {selectedMonth}.
                </div>
              ) : (
                monthRecordings.map((rec) => (
                  <div
                    key={rec.id}
                    className="p-4 rounded-2xl bg-slate-50 border border-slate-200/90 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider">
                          {rec.chapter}
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                          rec.videoUrl.includes('youtu') ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        }`}>
                          {rec.videoUrl.includes('youtu') ? 'YouTube' : 'MP4 Video'}
                        </span>
                      </div>
                      <h4 className="font-bold text-xs sm:text-sm text-slate-900">{rec.title}</h4>
                      <p className="text-xs text-slate-600">{rec.description}</p>
                      <div className="text-[11px] text-slate-500 flex items-center space-x-3 pt-1 font-medium">
                        <span>Duration: {rec.duration}</span>
                        {rec.resources && rec.resources.length > 0 && (
                          <span className="text-emerald-700 font-bold">Includes {rec.resources.length} Downloadable Files</span>
                        )}
                      </div>
                    </div>

                    <button
                      id={`btn-play-rec-${rec.id}`}
                      onClick={() => onPlayRecording(rec)}
                      className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition-all flex items-center space-x-1.5 shrink-0 cursor-pointer"
                    >
                      <Play className="w-4 h-4 fill-white" />
                      <span>Watch Video</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          )}

        </div>

        {/* Modal Footer with Monthly Subscription Trigger & Explicit Close Button */}
        <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
          <div>
            <div className="text-xs text-slate-500 font-medium">Monthly Tuition ({selectedMonth})</div>
            <div className="text-2xl font-black text-slate-900">Rs. {course.price.toLocaleString()}</div>
          </div>

          <div className="flex items-center space-x-3 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-3 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs transition-colors cursor-pointer min-h-[44px]"
            >
              Close
            </button>

            {isEnrolledInSelectedMonth ? (
              <div className="flex-1 sm:flex-initial flex items-center justify-center space-x-2 text-emerald-700 text-xs font-bold bg-emerald-50 border border-emerald-200 px-4 py-3 rounded-xl min-h-[44px]">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Active Access for {selectedMonth}</span>
              </div>
            ) : pendingPaymentForMonth ? (
              <div className="flex-1 sm:flex-initial flex items-center justify-center space-x-2 text-amber-800 text-xs font-bold bg-amber-50 border border-amber-200 px-4 py-3 rounded-xl min-h-[44px]">
                <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
                <span>{selectedMonth} Payment Pending Approval</span>
              </div>
            ) : (
              <button
                id="modal-btn-purchase-now"
                onClick={() => {
                  onClose();
                  onPurchase(course);
                }}
                className="flex-1 sm:flex-initial px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all cursor-pointer min-h-[44px] flex items-center justify-center"
              >
                Purchase {selectedMonth} Access (Rs. {course.price.toLocaleString()}/mo)
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { User } from '../types';
import {
  BookOpen,
  Calendar,
  CreditCard,
  GraduationCap,
  LogOut,
  PlusCircle,
  ShieldAlert,
  ShieldCheck,
  User as UserIcon,
  Video,
  VideoIcon
} from 'lucide-react';

interface NavbarProps {
  user: User | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAuth: (defaultRole?: 'student' | 'admin', isRegister?: boolean) => void;
  onLogout: () => void;
  pendingPaymentCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  activeTab,
  setActiveTab,
  onOpenAuth,
  onLogout,
  pendingPaymentCount,
}) => {

  return (
    <>
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 text-slate-800 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            
            {/* Brand Logo & Name */}
            <div className="flex items-center space-x-2.5 cursor-pointer" onClick={() => setActiveTab(user?.role === 'admin' ? 'admin-dashboard' : 'explore')}>
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center shadow-md shadow-indigo-100 shrink-0">
                <GraduationCap className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div>
                <span className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900 block leading-tight">
                  Academialk
                </span>
                <span className="text-[10px] text-slate-500 font-medium block sm:hidden">Mobile Portal</span>
              </div>
            </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1">
            {user?.role === 'admin' ? (
              <>
                <button
                  id="nav-admin-dashboard"
                  onClick={() => setActiveTab('admin-dashboard')}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center space-x-2 ${
                    activeTab === 'admin-dashboard'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Admin Dashboard</span>
                </button>

                <button
                  id="nav-admin-payments"
                  onClick={() => setActiveTab('admin-payments')}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center space-x-2 relative ${
                    activeTab === 'admin-payments'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-amber-600" />
                  <span>Payment Approvals</span>
                  {pendingPaymentCount > 0 && (
                    <span className="ml-1 px-2 py-0.5 text-xs font-bold bg-amber-500 text-white rounded-full animate-pulse">
                      {pendingPaymentCount}
                    </span>
                  )}
                </button>

                <button
                  id="nav-admin-courses"
                  onClick={() => setActiveTab('admin-courses')}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center space-x-2 ${
                    activeTab === 'admin-courses'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <BookOpen className="w-4 h-4 text-emerald-600" />
                  <span>Manage Courses</span>
                </button>

                <button
                  id="nav-admin-zoom"
                  onClick={() => setActiveTab('admin-zoom')}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center space-x-2 ${
                    activeTab === 'admin-zoom'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Video className="w-4 h-4 text-sky-600" />
                  <span>Zoom & Recordings</span>
                </button>
              </>
            ) : (
              <>
                <button
                  id="nav-explore"
                  onClick={() => setActiveTab('explore')}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center space-x-2 ${
                    activeTab === 'explore'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <BookOpen className="w-4 h-4 text-indigo-600" />
                  <span>Explore Courses</span>
                </button>

                <button
                  id="nav-my-learning"
                  onClick={() => setActiveTab('my-learning')}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center space-x-2 ${
                    activeTab === 'my-learning'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <GraduationCap className="w-4 h-4 text-emerald-600" />
                  <span>My Learning</span>
                </button>

                <button
                  id="nav-live-schedule"
                  onClick={() => setActiveTab('live-schedule')}
                  className={`px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center space-x-2 ${
                    activeTab === 'live-schedule'
                      ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Calendar className="w-4 h-4 text-amber-600" />
                  <span>Zoom Classes</span>
                </button>

                {user && (
                  <button
                    id="nav-profile"
                    onClick={() => setActiveTab('profile')}
                    className={`px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center space-x-2 ${
                      activeTab === 'profile'
                        ? 'bg-indigo-50 text-indigo-700 font-semibold border border-indigo-100'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <UserIcon className="w-4 h-4 text-violet-600" />
                    <span>My Profile</span>
                  </button>
                )}
              </>
            )}
          </nav>

          {/* User Auth Actions */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {user ? (
              <div className="flex items-center space-x-2 sm:space-x-3">
                <div 
                  onClick={() => setActiveTab(user.role === 'admin' ? 'admin-dashboard' : 'profile')}
                  className="flex items-center space-x-2 cursor-pointer bg-slate-100 hover:bg-slate-200/80 p-1.5 rounded-xl border border-slate-200 transition-colors"
                >
                  <img
                    src={user.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80'}
                    alt={user.name}
                    className="w-8 h-8 rounded-lg object-cover border border-indigo-200"
                  />
                  <div className="hidden lg:block text-left pr-1">
                    <div className="text-xs font-semibold text-slate-800 leading-tight">
                      {user.name}
                    </div>
                    <div className="text-[10px] text-indigo-600 font-medium capitalize flex items-center space-x-1">
                      {user.role === 'admin' ? (
                        <>
                          <ShieldCheck className="w-3 h-3 text-indigo-600 inline" />
                          <span>Admin</span>
                        </>
                      ) : (
                        <span>Student</span>
                      )}
                    </div>
                  </div>
                </div>

                <button
                  id="btn-logout"
                  onClick={onLogout}
                  className="p-2 text-slate-500 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  id="btn-open-login"
                  onClick={() => onOpenAuth('student', false)}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 transition-colors"
                >
                  Login
                </button>

                <button
                  id="btn-open-register"
                  onClick={() => onOpenAuth('student', true)}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-all"
                >
                  Create Account
                </button>
              </div>
            )}
          </div>

        </div>
      </div>
    </header>

    {/* Mobile Touch-Optimized Bottom Navigation Bar */}
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-lg border-t border-slate-200 md:hidden px-2 py-1 shadow-lg">
      <div className="grid grid-cols-4 gap-1 max-w-md mx-auto">
        {user?.role === 'admin' ? (
          <>
            <button
              id="mobile-nav-admin-dash"
              onClick={() => setActiveTab('admin-dashboard')}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer min-h-[48px] ${
                activeTab === 'admin-dashboard'
                  ? 'text-indigo-600 font-bold bg-indigo-50/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-5 h-5" />
              <span className="text-[10px] tracking-tight mt-0.5">Dashboard</span>
            </button>

            <button
              id="mobile-nav-admin-payments"
              onClick={() => setActiveTab('admin-payments')}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all relative cursor-pointer min-h-[48px] ${
                activeTab === 'admin-payments'
                  ? 'text-amber-600 font-bold bg-amber-50/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <div className="relative">
                <CreditCard className="w-5 h-5" />
                {pendingPaymentCount > 0 && (
                  <span className="absolute -top-1 -right-2 px-1.5 py-0.2 text-[9px] font-bold bg-amber-500 text-white rounded-full">
                    {pendingPaymentCount}
                  </span>
                )}
              </div>
              <span className="text-[10px] tracking-tight mt-0.5">Approvals</span>
            </button>

            <button
              id="mobile-nav-admin-courses"
              onClick={() => setActiveTab('admin-courses')}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer min-h-[48px] ${
                activeTab === 'admin-courses'
                  ? 'text-emerald-600 font-bold bg-emerald-50/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-5 h-5" />
              <span className="text-[10px] tracking-tight mt-0.5">Courses</span>
            </button>

            <button
              id="mobile-nav-admin-zoom"
              onClick={() => setActiveTab('admin-zoom')}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer min-h-[48px] ${
                activeTab === 'admin-zoom'
                  ? 'text-sky-600 font-bold bg-sky-50/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Video className="w-5 h-5" />
              <span className="text-[10px] tracking-tight mt-0.5">Zoom/Rec</span>
            </button>
          </>
        ) : (
          <>
            <button
              id="mobile-nav-explore"
              onClick={() => setActiveTab('explore')}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer min-h-[48px] ${
                activeTab === 'explore'
                  ? 'text-indigo-600 font-bold bg-indigo-50/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-5 h-5" />
              <span className="text-[10px] tracking-tight mt-0.5">Explore</span>
            </button>

            <button
              id="mobile-nav-my-learning"
              onClick={() => setActiveTab('my-learning')}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer min-h-[48px] ${
                activeTab === 'my-learning'
                  ? 'text-emerald-600 font-bold bg-emerald-50/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-5 h-5" />
              <span className="text-[10px] tracking-tight mt-0.5">My Learning</span>
            </button>

            <button
              id="mobile-nav-live-schedule"
              onClick={() => setActiveTab('live-schedule')}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer min-h-[48px] ${
                activeTab === 'live-schedule'
                  ? 'text-amber-600 font-bold bg-amber-50/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-5 h-5" />
              <span className="text-[10px] tracking-tight mt-0.5">Zoom Live</span>
            </button>

            <button
              id="mobile-nav-profile"
              onClick={() => {
                if (user) {
                  setActiveTab('profile');
                } else {
                  onOpenAuth('student', false);
                }
              }}
              className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition-all cursor-pointer min-h-[48px] ${
                activeTab === 'profile'
                  ? 'text-violet-600 font-bold bg-violet-50/80'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <UserIcon className="w-5 h-5" />
              <span className="text-[10px] tracking-tight mt-0.5">{user ? 'Profile' : 'Login'}</span>
            </button>
          </>
        )}
      </div>
    </nav>
  </>
);
};

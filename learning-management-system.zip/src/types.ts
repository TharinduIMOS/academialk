export type UserRole = 'student' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
  phone?: string;
  bio?: string;
  enrolledCourseIds: string[]; // e.g., ['physics', 'chemistry']
  enrolledMonthKeys: string[]; // e.g., ['physics_July 2026', 'biology_August 2026']
  createdAt: string;
}

export interface ZoomSession {
  id: string;
  courseId: string;
  month: string; // e.g., 'July 2026', 'August 2026'
  title: string;
  scheduledAt: string; // ISO format or readable date-time string
  durationMinutes: number;
  zoomUrl: string;
  meetingId: string;
  passcode: string;
  status: 'upcoming' | 'live' | 'ended';
  hostName?: string;
}

export interface ResourceAttachment {
  id: string;
  title: string;
  url: string;
  type: 'pdf' | 'code' | 'zip' | 'link';
}

export interface VideoRecording {
  id: string;
  courseId: string;
  month: string; // e.g., 'July 2026', 'August 2026'
  title: string;
  videoUrl: string; // video MP4 URL or embed URL
  duration: string;
  chapter: string;
  description: string;
  resources?: ResourceAttachment[];
}

export interface Course {
  id: string;
  title: string;
  category: string; // Physics, Biology, Chemistry, Combined Maths
  batch?: string; // e.g., '2026 A/L', '2027 A/L', '2028 A/L'
  description: string;
  instructor: string;
  instructorAvatar?: string;
  instructorTitle?: string;
  instructorBio?: string;
  price: number; // Monthly fee
  originalPrice?: number;
  image: string;
  rating: number;
  reviewsCount: number;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';
  scheduleText: string;
  availableMonths: string[]; // ['July 2026', 'August 2026', 'September 2026', ...]
  zoomSessions: ZoomSession[];
  recordings: VideoRecording[];
  tags: string[];
}

export interface PaymentTransaction {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userAvatar?: string;
  courseId: string;
  month: string; // e.g. 'July 2026'
  courseTitle: string;
  coursePrice: number;
  amount: number;
  paymentMethod: 'card' | 'bank_transfer' | 'paypal';
  receiptUrl?: string;
  referenceCode: string;
  note?: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedAt?: string;
  rejectionReason?: string;
}

export interface DashboardStats {
  totalStudents: number;
  totalRevenue: number;
  pendingApprovals: number;
  activeCourses: number;
  upcomingZoomClasses: number;
}
